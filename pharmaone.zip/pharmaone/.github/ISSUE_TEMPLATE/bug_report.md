---
name: Bug Report
about: Report a bug in PharmaOne
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description
A clear description of what the bug is.

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. See error

## Expected Behavior
What you expected to happen.

## Actual Behavior
What actually happened.

## Screenshots
If applicable, add screenshots.

## Environment
- Browser: [e.g. Chrome 120]
- OS: [e.g. Windows 11]
- Role: [Patient / Doctor / Admin]

## Additional Context
Any other relevant information.
