---
name: Feature Request
about: Suggest a new feature or improvement
title: '[FEAT] '
labels: enhancement
assignees: ''
---

## Feature Summary
A concise description of what you want.

## Problem it Solves
Describe the problem this feature addresses.

## Proposed Solution
How you'd like it to work.

## Module
Which PharmaOne module does this affect?
- [ ] Medicines / Orders
- [ ] eNotes & Lectures
- [ ] AI Research Analyzer
- [ ] Online Doctor Visits
- [ ] Jobs & Internships
- [ ] AI Navigator (PharmaBot)
- [ ] Auth / Profile
- [ ] Admin Panel

## Additional Context
Mockups, examples, or links.
