## Summary
<!-- Brief description of what this PR does -->

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Refactor / code improvement
- [ ] Documentation update
- [ ] CI/CD / DevOps

## Module(s) Affected
- [ ] Backend API
- [ ] Frontend UI
- [ ] Medicines
- [ ] Notes / Lectures
- [ ] Research (AI)
- [ ] Doctors / Appointments
- [ ] Jobs
- [ ] AI Navigator
- [ ] Auth

## Testing
- [ ] I have tested this locally
- [ ] I have added/updated tests
- [ ] All existing tests pass

## Screenshots (if UI change)
<!-- Add before/after screenshots for any UI changes -->

## Checklist
- [ ] Code follows project style guidelines
- [ ] No `.env` files or secrets committed
- [ ] Self-reviewed my own code
- [ ] PR title follows format: `type: short description` (e.g., `feat: add prescription upload`)

## Related Issues
Closes #
