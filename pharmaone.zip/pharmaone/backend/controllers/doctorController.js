const asyncHandler = require('express-async-handler');
const User = require('../models/User');
const { Appointment } = require('../models/index');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { v4: uuidv4 } = require('uuid');

// ─── Doctors ──────────────────────────────────────────────────────────────────
const getDoctors = asyncHandler(async (req, res) => {
  const { specialization, search, page = 1, limit = 12 } = req.query;
  const query = { role: 'doctor', isActive: true, isVerified: true };

  if (specialization) query.specialization = specialization;
  if (search) query.$or = [
    { name: { $regex: search, $options: 'i' } },
    { specialization: { $regex: search, $options: 'i' } },
  ];

  const skip = (Number(page) - 1) * Number(limit);
  const [doctors, total] = await Promise.all([
    User.find(query).select('-password -savedNotes -savedJobs').skip(skip).limit(Number(limit)).sort({ rating: -1 }),
    User.countDocuments(query),
  ]);

  res.json({ success: true, doctors, total, pages: Math.ceil(total / Number(limit)) });
});

const getDoctorById = asyncHandler(async (req, res) => {
  const doctor = await User.findOne({ _id: req.params.id, role: 'doctor' }).select('-password');
  if (!doctor) { res.status(404); throw new Error('Doctor not found'); }
  res.json({ success: true, doctor });
});

// ─── Appointments ─────────────────────────────────────────────────────────────
const bookAppointment = asyncHandler(async (req, res) => {
  const { doctorId, date, slot, type, symptoms } = req.body;

  const doctor = await User.findOne({ _id: doctorId, role: 'doctor' });
  if (!doctor) { res.status(404); throw new Error('Doctor not found'); }

  // Check slot not already booked
  const existing = await Appointment.findOne({
    doctor: doctorId,
    date: new Date(date),
    'slot.start': slot.start,
    status: { $nin: ['Cancelled'] },
  });
  if (existing) { res.status(400); throw new Error('This slot is already booked'); }

  const roomId = uuidv4();

  const appointment = await Appointment.create({
    patient: req.user._id,
    doctor: doctorId,
    date: new Date(date),
    slot,
    type,
    symptoms,
    fee: doctor.consultationFee || 500,
    roomId,
    status: 'Pending',
  });

  // Create Stripe payment intent
  const paymentIntent = await stripe.paymentIntents.create({
    amount: Math.round((doctor.consultationFee || 500) * 100),
    currency: 'inr',
    metadata: { appointmentId: appointment._id.toString() },
  });

  appointment.stripePaymentIntentId = paymentIntent.id;
  await appointment.save();

  res.status(201).json({
    success: true,
    appointment: await appointment.populate('doctor', 'name avatar specialization'),
    clientSecret: paymentIntent.client_secret,
  });
});

const getMyAppointments = asyncHandler(async (req, res) => {
  const query = req.user.role === 'doctor' ? { doctor: req.user._id } : { patient: req.user._id };
  const appointments = await Appointment.find(query)
    .sort({ date: -1 })
    .populate('patient', 'name avatar')
    .populate('doctor', 'name avatar specialization');
  res.json({ success: true, appointments });
});

const getAppointmentById = asyncHandler(async (req, res) => {
  const appointment = await Appointment.findById(req.params.id)
    .populate('patient', 'name avatar email phone')
    .populate('doctor', 'name avatar specialization qualification');

  if (!appointment) { res.status(404); throw new Error('Appointment not found'); }

  const isInvolved = [appointment.patient._id.toString(), appointment.doctor._id.toString()].includes(req.user._id.toString());
  if (!isInvolved && req.user.role !== 'admin') { res.status(403); throw new Error('Not authorized'); }

  res.json({ success: true, appointment });
});

const updateAppointmentStatus = asyncHandler(async (req, res) => {
  const { status, notes, prescription } = req.body;
  const appointment = await Appointment.findById(req.params.id);
  if (!appointment) { res.status(404); throw new Error('Appointment not found'); }

  appointment.status = status;
  if (notes) appointment.notes = notes;
  if (prescription) appointment.prescription = prescription;
  await appointment.save();

  // Notify via socket
  const io = req.app.get('io');
  io.to(appointment.roomId).emit('appointment:status', { status, appointmentId: appointment._id });

  res.json({ success: true, appointment });
});

const rateAppointment = asyncHandler(async (req, res) => {
  const { rating, review } = req.body;
  const appointment = await Appointment.findById(req.params.id);

  if (!appointment) { res.status(404); throw new Error('Not found'); }
  if (appointment.patient.toString() !== req.user._id.toString()) { res.status(403); throw new Error('Not authorized'); }
  if (appointment.status !== 'Completed') { res.status(400); throw new Error('Can only rate completed appointments'); }

  appointment.rating = rating;
  appointment.review = review;
  await appointment.save();

  // Update doctor's rating
  const doctor = await User.findById(appointment.doctor);
  doctor.totalReviews += 1;
  doctor.rating = ((doctor.rating * (doctor.totalReviews - 1)) + rating) / doctor.totalReviews;
  await doctor.save();

  res.json({ success: true, message: 'Rating submitted' });
});

module.exports = { getDoctors, getDoctorById, bookAppointment, getMyAppointments, getAppointmentById, updateAppointmentStatus, rateAppointment };
