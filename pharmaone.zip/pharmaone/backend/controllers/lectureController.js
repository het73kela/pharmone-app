const asyncHandler = require('express-async-handler');
const { Lecture } = require('../models/index');

const getLectures = asyncHandler(async (req, res) => {
  const { search, subject, year, page = 1, limit = 15 } = req.query;
  const query = { isApproved: true };
  if (search) query.$text = { $search: search };
  if (subject) query.subject = subject;
  if (year) query.year = year;

  const skip = (Number(page) - 1) * Number(limit);
  const [lectures, total] = await Promise.all([
    Lecture.find(query).sort({ isFeatured: -1, views: -1 }).skip(skip).limit(Number(limit)),
    Lecture.countDocuments(query),
  ]);
  res.json({ success: true, lectures, total, pages: Math.ceil(total / Number(limit)) });
});

const getLectureById = asyncHandler(async (req, res) => {
  const lecture = await Lecture.findByIdAndUpdate(req.params.id, { $inc: { views: 1 } }, { new: true });
  if (!lecture) { res.status(404); throw new Error('Lecture not found'); }
  res.json({ success: true, lecture });
});

const createLecture = asyncHandler(async (req, res) => {
  const lecture = await Lecture.create(req.body);
  res.status(201).json({ success: true, lecture });
});

const likeLecture = asyncHandler(async (req, res) => {
  const lecture = await Lecture.findById(req.params.id);
  if (!lecture) { res.status(404); throw new Error('Lecture not found'); }
  const liked = lecture.likes.includes(req.user._id);
  if (liked) lecture.likes.pull(req.user._id);
  else lecture.likes.push(req.user._id);
  await lecture.save();
  res.json({ success: true, liked: !liked });
});

module.exports = { getLectures, getLectureById, createLecture, likeLecture };
