const asyncHandler = require('express-async-handler');
const Order = require('../models/Order');
const Medicine = require('../models/Medicine');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

// POST /api/orders
const createOrder = asyncHandler(async (req, res) => {
  const { items, shippingAddress, paymentMethod } = req.body;

  if (!items || items.length === 0) {
    res.status(400); throw new Error('No items in order');
  }

  // Validate stock and calculate totals
  let subtotal = 0;
  const orderItems = [];

  for (const item of items) {
    const medicine = await Medicine.findById(item.medicineId);
    if (!medicine) { res.status(404); throw new Error(`Medicine ${item.medicineId} not found`); }
    if (medicine.stock < item.quantity) {
      res.status(400); throw new Error(`Insufficient stock for ${medicine.name}`);
    }
    orderItems.push({ medicine: medicine._id, quantity: item.quantity, price: medicine.finalPrice, name: medicine.name });
    subtotal += medicine.finalPrice * item.quantity;
  }

  const shippingFee = subtotal >= 500 ? 0 : 40;
  const total = subtotal + shippingFee;

  const order = await Order.create({
    user: req.user._id,
    items: orderItems,
    shippingAddress,
    subtotal,
    shippingFee,
    total,
    paymentMethod,
    trackingHistory: [{ status: 'Placed', message: 'Order placed successfully' }],
    estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // +3 days
  });

  // Reduce stock
  for (const item of orderItems) {
    await Medicine.findByIdAndUpdate(item.medicine, { $inc: { stock: -item.quantity } });
  }

  // Create Stripe payment intent if online payment
  let clientSecret = null;
  if (paymentMethod === 'Online') {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(total * 100), // paise
      currency: 'inr',
      metadata: { orderId: order._id.toString() },
    });
    order.stripePaymentIntentId = paymentIntent.id;
    await order.save();
    clientSecret = paymentIntent.client_secret;
  }

  res.status(201).json({ success: true, order, clientSecret });
});

// GET /api/orders/my
const getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 }).populate('items.medicine', 'name images');
  res.json({ success: true, orders });
});

// GET /api/orders/:id
const getOrderById = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id).populate('items.medicine', 'name images brand').populate('user', 'name email');
  if (!order) { res.status(404); throw new Error('Order not found'); }
  if (order.user._id.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
    res.status(403); throw new Error('Not authorized');
  }
  res.json({ success: true, order });
});

// PUT /api/orders/:id/status — admin/pharmacist
const updateOrderStatus = asyncHandler(async (req, res) => {
  const { status, message } = req.body;
  const order = await Order.findById(req.params.id);
  if (!order) { res.status(404); throw new Error('Order not found'); }

  order.orderStatus = status;
  order.trackingHistory.push({ status, message: message || `Order ${status}` });
  if (status === 'Delivered') order.deliveredAt = Date.now();

  await order.save();
  res.json({ success: true, order });
});

// POST /api/orders/:id/cancel
const cancelOrder = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) { res.status(404); throw new Error('Order not found'); }
  if (order.user.toString() !== req.user._id.toString()) { res.status(403); throw new Error('Not authorized'); }
  if (['Shipped', 'OutForDelivery', 'Delivered'].includes(order.orderStatus)) {
    res.status(400); throw new Error('Cannot cancel order at this stage');
  }

  order.orderStatus = 'Cancelled';
  order.cancelReason = req.body.reason || 'Cancelled by user';
  order.trackingHistory.push({ status: 'Cancelled', message: order.cancelReason });

  // Restore stock
  for (const item of order.items) {
    await Medicine.findByIdAndUpdate(item.medicine, { $inc: { stock: item.quantity } });
  }

  await order.save();
  res.json({ success: true, order });
});

// GET /api/orders — admin
const getAllOrders = asyncHandler(async (req, res) => {
  const { status, page = 1, limit = 20 } = req.query;
  const query = status ? { orderStatus: status } : {};
  const skip = (Number(page) - 1) * Number(limit);
  const [orders, total] = await Promise.all([
    Order.find(query).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)).populate('user', 'name email'),
    Order.countDocuments(query),
  ]);
  res.json({ success: true, orders, total, pages: Math.ceil(total / Number(limit)) });
});

module.exports = { createOrder, getMyOrders, getOrderById, updateOrderStatus, cancelOrder, getAllOrders };
