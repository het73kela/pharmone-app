const mongoose = require('mongoose');

const noteSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: String,
    subject: {
      type: String,
      enum: [
        'Pharmacology',
        'Pharmaceutics',
        'Pharmacognosy',
        'Pharmaceutical Chemistry',
        'Clinical Pharmacy',
        'Hospital Pharmacy',
        'Community Pharmacy',
        'Toxicology',
        'Biochemistry',
        'Anatomy & Physiology',
        'Microbiology',
        'Other',
      ],
      required: true,
    },
    year: { type: String, enum: ['1st Year', '2nd Year', '3rd Year', '4th Year', 'M.Pharm', 'Ph.D'] },
    type: { type: String, enum: ['Notes', 'Textbook', 'Question Paper', 'Handwritten', 'Slides'], default: 'Notes' },
    fileUrl: { type: String, required: true },
    coverImage: String,
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    tags: [String],
    downloads: { type: Number, default: 0 },
    views: { type: Number, default: 0 },
    likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    isApproved: { type: Boolean, default: false },
    isFeatured: { type: Boolean, default: false },
    isFree: { type: Boolean, default: true },
    price: { type: Number, default: 0 },
  },
  { timestamps: true }
);

noteSchema.index({ title: 'text', description: 'text', tags: 'text', subject: 'text' });

module.exports = mongoose.model('Note', noteSchema);
