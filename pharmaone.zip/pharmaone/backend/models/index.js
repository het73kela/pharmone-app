const mongoose = require('mongoose');

// ─── Lecture ──────────────────────────────────────────────────────────────────
const lectureSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: String,
    subject: { type: String, required: true },
    year: String,
    videoUrl: { type: String, required: true }, // YouTube embed or Cloudinary
    thumbnail: String,
    duration: String, // e.g. "45 min"
    instructor: String,
    tags: [String],
    views: { type: Number, default: 0 },
    likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    isApproved: { type: Boolean, default: true },
    isFeatured: { type: Boolean, default: false },
  },
  { timestamps: true }
);

// ─── Appointment ──────────────────────────────────────────────────────────────
const appointmentSchema = new mongoose.Schema(
  {
    patient: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    doctor: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    date: { type: Date, required: true },
    slot: { start: String, end: String },
    type: { type: String, enum: ['Video', 'Chat'], default: 'Video' },
    status: {
      type: String,
      enum: ['Pending', 'Confirmed', 'InProgress', 'Completed', 'Cancelled'],
      default: 'Pending',
    },
    symptoms: String,
    notes: String, // Doctor's notes post-consultation
    prescription: String, // PDF URL
    fee: Number,
    paymentStatus: { type: String, enum: ['Pending', 'Paid', 'Refunded'], default: 'Pending' },
    stripePaymentIntentId: String,
    roomId: String, // Socket.io / WebRTC room ID
    rating: Number,
    review: String,
    cancelReason: String,
  },
  { timestamps: true }
);

// ─── Job ──────────────────────────────────────────────────────────────────────
const jobSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    company: { type: String, required: true },
    companyLogo: String,
    location: String,
    locationType: { type: String, enum: ['Remote', 'On-site', 'Hybrid'], default: 'On-site' },
    type: {
      type: String,
      enum: ['Full-time', 'Part-time', 'Internship', 'Contract', 'Residency', 'Fellowship'],
      required: true,
    },
    category: {
      type: String,
      enum: ['Hospital Pharmacy', 'Community Pharmacy', 'Clinical Research', 'Manufacturing', 'Regulatory Affairs', 'Academia', 'Other'],
    },
    description: { type: String, required: true },
    requirements: [String],
    responsibilities: [String],
    skills: [String],
    salaryMin: Number,
    salaryMax: Number,
    salaryCurrency: { type: String, default: 'INR' },
    deadline: Date,
    postedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    applications: [
      {
        user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        resume: String,
        coverLetter: String,
        status: { type: String, enum: ['Applied', 'Shortlisted', 'Rejected', 'Hired'], default: 'Applied' },
        appliedAt: { type: Date, default: Date.now },
      },
    ],
    views: { type: Number, default: 0 },
    isActive: { type: Boolean, default: true },
    isFeatured: { type: Boolean, default: false },
  },
  { timestamps: true }
);

jobSchema.index({ title: 'text', company: 'text', skills: 'text' });

// ─── Research Paper ───────────────────────────────────────────────────────────
const researchSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    title: String,
    abstract: String,
    authors: [String],
    journal: String,
    publishedDate: Date,
    doi: String,
    pubmedId: String,
    pdfUrl: String,
    source: { type: String, enum: ['Upload', 'PubMed', 'SemanticScholar'], default: 'Upload' },
    aiSummary: String,
    aiKeyFindings: [String],
    aiMethodology: String,
    aiConclusion: String,
    aiLimitations: [String],
    aiRelevanceScore: Number,
    tags: [String],
    savedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  },
  { timestamps: true }
);

module.exports = {
  Lecture: mongoose.model('Lecture', lectureSchema),
  Appointment: mongoose.model('Appointment', appointmentSchema),
  Job: mongoose.model('Job', jobSchema),
  Research: mongoose.model('Research', researchSchema),
};
