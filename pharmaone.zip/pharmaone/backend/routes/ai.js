const express = require('express');
const router = express.Router();
const { aiChat } = require('../controllers/aiController');
const { optionalAuth } = require('../middleware/authMiddleware');

router.post('/chat', optionalAuth, aiChat);
module.exports = router;
