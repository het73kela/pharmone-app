const express = require('express');
const router = express.Router();
const { bookAppointment, getMyAppointments, getAppointmentById, updateAppointmentStatus, rateAppointment } = require('../controllers/doctorController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.post('/', protect, bookAppointment);
router.get('/my', protect, getMyAppointments);
router.get('/:id', protect, getAppointmentById);
router.put('/:id/status', protect, authorize('doctor', 'admin'), updateAppointmentStatus);
router.post('/:id/rate', protect, rateAppointment);
module.exports = router;
