const express = require('express');
const router = express.Router();
const { getJobs, getJobById, createJob, applyForJob, getMyApplications, updateApplicationStatus, saveJob } = require('../controllers/jobController');
const { protect, authorize } = require('../middleware/authMiddleware');
const { uploadPDF } = require('../config/cloudinary');

router.get('/', getJobs);
router.get('/applications/my', protect, getMyApplications);
router.get('/:id', getJobById);
router.post('/', protect, authorize('admin'), createJob);
router.post('/:id/apply', protect, uploadPDF.single('resume'), applyForJob);
router.put('/:id/application-status', protect, authorize('admin'), updateApplicationStatus);
router.post('/:id/save', protect, saveJob);
module.exports = router;
