const express = require('express');
const router = express.Router();
const { getLectures, getLectureById, createLecture, likeLecture } = require('../controllers/lectureController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.get('/', getLectures);
router.get('/:id', getLectureById);
router.post('/', protect, authorize('admin'), createLecture);
router.post('/:id/like', protect, likeLecture);
module.exports = router;
