const express = require('express');
const router = express.Router();
const { getMedicines, getMedicineById, createMedicine, updateMedicine, deleteMedicine, addReview } = require('../controllers/medicineController');
const { protect, authorize } = require('../middleware/authMiddleware');
const { uploadImage } = require('../config/cloudinary');

router.get('/', getMedicines);
router.get('/:id', getMedicineById);
router.post('/', protect, authorize('admin', 'pharmacist'), uploadImage.array('images', 5), createMedicine);
router.put('/:id', protect, authorize('admin', 'pharmacist'), updateMedicine);
router.delete('/:id', protect, authorize('admin'), deleteMedicine);
router.post('/:id/review', protect, addReview);

module.exports = router;
