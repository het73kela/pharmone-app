const express = require('express');
const router = express.Router();
const { getNotes, getNoteById, createNote, downloadNote, likeNote, approveNote } = require('../controllers/noteController');
const { protect, authorize, optionalAuth } = require('../middleware/authMiddleware');
const { uploadPDF } = require('../config/cloudinary');

router.get('/', getNotes);
router.get('/:id', getNoteById);
router.post('/', protect, uploadPDF.single('file'), createNote);
router.get('/:id/download', protect, downloadNote);
router.post('/:id/like', protect, likeNote);
router.put('/:id/approve', protect, authorize('admin'), approveNote);
module.exports = router;
