const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const Order = require('../models/Order');
const { Appointment } = require('../models/index');
const { protect } = require('../middleware/authMiddleware');

router.post('/confirm', protect, asyncHandler(async (req, res) => {
  const { paymentIntentId, type, id } = req.body;
  const intent = await stripe.paymentIntents.retrieve(paymentIntentId);
  if (intent.status !== 'succeeded') { res.status(400); throw new Error('Payment not successful'); }
  if (type === 'order') await Order.findByIdAndUpdate(id, { paymentStatus: 'Paid', orderStatus: 'Confirmed' });
  else if (type === 'appointment') await Appointment.findByIdAndUpdate(id, { paymentStatus: 'Paid', status: 'Confirmed' });
  res.json({ success: true, message: 'Payment confirmed' });
}));

module.exports = router;
