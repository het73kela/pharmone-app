const express = require('express');
const router = express.Router();
const { analyzePaper, searchResearch, summarizePubmedPaper, getMyResearch } = require('../controllers/aiController');
const { protect, optionalAuth } = require('../middleware/authMiddleware');
const { uploadToMemory } = require('../config/cloudinary');

router.post('/analyze', protect, uploadToMemory.single('pdf'), analyzePaper);
router.get('/search', searchResearch);
router.post('/summarize-pubmed', optionalAuth, summarizePubmedPaper);
router.get('/my', protect, getMyResearch);
module.exports = router;
