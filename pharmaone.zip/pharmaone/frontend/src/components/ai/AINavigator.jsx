import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FiMessageCircle, FiX, FiSend, FiZap } from 'react-icons/fi';
import api from '../../utils/api';

const QUICK_STARTS = [
  'I need to order medicines 💊',
  'Find pharmacy study notes 📚',
  'Book a doctor consultation 👨‍⚕️',
  'Analyze a research paper 🔬',
  'Browse pharmacy jobs 💼',
];

export default function AINavigator() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: "Hi! I'm **PharmaBot** 👋\n\nI'm your AI guide for PharmaOne. I can help you find medicines, study notes, book doctor visits, analyze research papers, and explore pharmacy careers.\n\nWhat do you need today?",
      quickReplies: QUICK_STARTS,
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 300);
  }, [open]);

  const sendMessage = async (text) => {
    const userText = text || input.trim();
    if (!userText) return;
    setInput('');

    const history = messages
      .filter((m) => m.role !== 'assistant' || messages.indexOf(m) > 0)
      .map((m) => ({ role: m.role, content: m.content }));

    setMessages((prev) => [...prev, { role: 'user', content: userText }]);
    setLoading(true);

    try {
      const { data } = await api.post('/ai/chat', {
        message: userText,
        conversationHistory: history.slice(-8),
      });

      const resp = data.response;
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: resp.message,
          quickReplies: resp.quickReplies || [],
          route: resp.route,
          action: resp.action,
        },
      ]);

      if (resp.action === 'navigate' && resp.route) {
        setTimeout(() => { navigate(resp.route); setOpen(false); }, 1200);
      }
    } catch {
      setMessages((prev) => [...prev, { role: 'assistant', content: "Sorry, I'm having trouble connecting right now. Please try again in a moment." }]);
    } finally {
      setLoading(false);
    }
  };

  const renderContent = (text) => {
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong class="text-teal-300">$1</strong>')
      .replace(/\n/g, '<br/>');
  };

  return (
    <>
      {/* Floating button */}
      <motion.button
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-2xl shadow-2xl shadow-teal-500/40 flex items-center justify-center text-white hover:scale-110 active:scale-95 transition-transform"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.div key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <FiX className="text-2xl" />
            </motion.div>
          ) : (
            <motion.div key="open" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}>
              <FiMessageCircle className="text-2xl" />
            </motion.div>
          )}
        </AnimatePresence>
        {/* Pulse ring */}
        {!open && <span className="absolute w-full h-full rounded-2xl bg-teal-400/30 animate-ping" />}
      </motion.button>

      {/* Chat window */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed bottom-24 right-6 z-50 w-[360px] max-w-[calc(100vw-48px)] h-[520px] flex flex-col glass rounded-2xl shadow-2xl shadow-black/60 overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-800 bg-slate-900/80">
              <div className="w-9 h-9 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg shadow-teal-500/30 flex-shrink-0">
                <FiZap className="text-white text-lg" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-100">PharmaBot</p>
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                  <p className="text-xs text-slate-400">AI Navigator · Always on</p>
                </div>
              </div>
              <button onClick={() => setOpen(false)} className="ml-auto text-slate-500 hover:text-slate-300 transition-colors">
                <FiX />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 scrollbar-thin">
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                      msg.role === 'user'
                        ? 'bg-teal-600 text-white rounded-br-sm'
                        : 'bg-slate-800 text-slate-200 rounded-bl-sm border border-slate-700/60'
                    }`}
                    dangerouslySetInnerHTML={{ __html: renderContent(msg.content) }}
                  />
                </div>
              ))}

              {/* Quick replies */}
              {messages[messages.length - 1]?.quickReplies?.length > 0 && !loading && (
                <div className="flex flex-wrap gap-2">
                  {messages[messages.length - 1].quickReplies.map((qr, i) => (
                    <button
                      key={i}
                      onClick={() => sendMessage(qr)}
                      className="text-xs bg-slate-800 hover:bg-teal-900/40 border border-slate-700 hover:border-teal-600 text-slate-300 hover:text-teal-300 px-3 py-1.5 rounded-xl transition-all duration-200"
                    >
                      {qr}
                    </button>
                  ))}
                </div>
              )}

              {/* Loading indicator */}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-slate-800 border border-slate-700 rounded-2xl rounded-bl-sm px-4 py-3">
                    <div className="flex gap-1.5 items-center">
                      {[0, 1, 2].map((i) => (
                        <motion.div key={i} className="w-2 h-2 bg-teal-400 rounded-full"
                          animate={{ y: [0, -6, 0] }} transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.15 }} />
                      ))}
                    </div>
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* Input */}
            <div className="p-3 border-t border-slate-800 bg-slate-900/60">
              <div className="flex gap-2">
                <input
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && sendMessage()}
                  placeholder="Ask me anything…"
                  disabled={loading}
                  className="flex-1 bg-slate-800/80 border border-slate-700 text-slate-200 placeholder-slate-500 text-sm rounded-xl px-4 py-2.5 focus:outline-none focus:border-teal-500 transition-colors disabled:opacity-50"
                />
                <button
                  onClick={() => sendMessage()}
                  disabled={loading || !input.trim()}
                  className="w-10 h-10 bg-teal-600 hover:bg-teal-500 disabled:opacity-40 rounded-xl flex items-center justify-center text-white transition-all active:scale-95"
                >
                  <FiSend className="text-sm" />
                </button>
              </div>
              <p className="text-center text-xs text-slate-600 mt-2">Powered by GPT-4o</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
