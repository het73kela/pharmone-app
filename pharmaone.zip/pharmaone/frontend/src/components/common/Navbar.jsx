import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FiShoppingCart, FiUser, FiMenu, FiX, FiLogOut,
  FiBook, FiVideo, FiSearch, FiBriefcase, FiActivity,
} from 'react-icons/fi';
import { MdLocalPharmacy, MdSick } from 'react-icons/md';
import { useAuthStore } from '../../context/authStore';
import { useCartStore } from '../../context/cartStore';

const navLinks = [
  { to: '/medicines', label: 'Medicines', icon: MdLocalPharmacy },
  { to: '/notes', label: 'Notes', icon: FiBook },
  { to: '/lectures', label: 'Lectures', icon: FiVideo },
  { to: '/research', label: 'Research', icon: FiSearch },
  { to: '/doctors', label: 'Doctors', icon: MdSick },
  { to: '/jobs', label: 'Jobs', icon: FiBriefcase },
];

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const { user, token, logout } = useAuthStore();
  const cartCount = useCartStore((s) => s.count);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => { setMobileOpen(false); }, [location]);

  const handleLogout = () => { logout(); navigate('/'); setProfileOpen(false); };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'glass shadow-xl shadow-black/20' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg shadow-teal-500/30 group-hover:scale-110 transition-transform">
              <FiActivity className="text-white text-sm" />
            </div>
            <span className="font-bold text-lg tracking-tight">
              <span className="gradient-text">Pharma</span>
              <span className="text-slate-100">One</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map(({ to, label, icon: Icon }) => (
              <Link
                key={to}
                to={to}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200
                  ${location.pathname.startsWith(to)
                    ? 'bg-teal-500/20 text-teal-400'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800'}`}
              >
                <Icon className="text-base" />
                {label}
              </Link>
            ))}
          </div>

          {/* Right side */}
          <div className="flex items-center gap-2">
            {/* Cart */}
            <Link to="/cart" className="relative p-2.5 text-slate-400 hover:text-teal-400 hover:bg-slate-800 rounded-xl transition-all">
              <FiShoppingCart className="text-xl" />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-teal-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                  {cartCount > 9 ? '9+' : cartCount}
                </span>
              )}
            </Link>

            {token ? (
              <div className="relative">
                <button
                  onClick={() => setProfileOpen(!profileOpen)}
                  className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-800 transition-all"
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-teal-600 to-cyan-600 rounded-xl flex items-center justify-center text-white text-sm font-bold">
                    {user?.name?.charAt(0).toUpperCase()}
                  </div>
                  <span className="hidden sm:block text-sm font-medium text-slate-300 max-w-[100px] truncate">{user?.name?.split(' ')[0]}</span>
                </button>

                <AnimatePresence>
                  {profileOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 8, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 8, scale: 0.95 }}
                      transition={{ duration: 0.15 }}
                      className="absolute right-0 top-12 w-52 card shadow-2xl shadow-black/50 z-50"
                    >
                      <div className="px-3 py-2 border-b border-slate-800 mb-1">
                        <p className="text-sm font-semibold text-slate-200 truncate">{user?.name}</p>
                        <p className="text-xs text-slate-500 truncate">{user?.email}</p>
                        <span className="badge bg-teal-900/50 text-teal-400 border border-teal-800 mt-1 capitalize">{user?.role}</span>
                      </div>
                      {[
                        { to: '/dashboard', label: 'Dashboard', icon: FiActivity },
                        { to: '/profile', label: 'Profile', icon: FiUser },
                        { to: '/orders', label: 'My Orders', icon: FiShoppingCart },
                        { to: '/appointments', label: 'Appointments', icon: MdSick },
                      ].map(({ to, label, icon: Icon }) => (
                        <Link key={to} to={to} onClick={() => setProfileOpen(false)}
                          className="flex items-center gap-2.5 px-3 py-2 text-sm text-slate-300 hover:bg-slate-800 hover:text-teal-400 rounded-xl transition-all">
                          <Icon className="text-base" /> {label}
                        </Link>
                      ))}
                      <hr className="border-slate-800 my-1" />
                      <button onClick={handleLogout}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-rose-400 hover:bg-rose-500/10 rounded-xl transition-all">
                        <FiLogOut className="text-base" /> Sign Out
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <div className="hidden sm:flex items-center gap-2">
                <Link to="/login" className="btn-ghost text-sm py-2">Sign In</Link>
                <Link to="/register" className="btn-primary text-sm py-2">Get Started</Link>
              </div>
            )}

            {/* Mobile menu toggle */}
            <button onClick={() => setMobileOpen(!mobileOpen)} className="lg:hidden p-2 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-xl transition-all">
              {mobileOpen ? <FiX className="text-xl" /> : <FiMenu className="text-xl" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden glass border-t border-slate-800"
          >
            <div className="px-4 py-4 space-y-1">
              {navLinks.map(({ to, label, icon: Icon }) => (
                <Link key={to} to={to}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all
                    ${location.pathname.startsWith(to) ? 'bg-teal-500/20 text-teal-400' : 'text-slate-300 hover:bg-slate-800'}`}
                >
                  <Icon className="text-lg" /> {label}
                </Link>
              ))}
              {!token && (
                <div className="flex gap-2 pt-2">
                  <Link to="/login" className="btn-secondary text-sm flex-1 text-center">Sign In</Link>
                  <Link to="/register" className="btn-primary text-sm flex-1 text-center">Get Started</Link>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
