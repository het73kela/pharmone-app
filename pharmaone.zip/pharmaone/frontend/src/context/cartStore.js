import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useCartStore = create(
  persist(
    (set, get) => ({
      items: [],

      addItem: (medicine, quantity = 1) => {
        const { items } = get();
        const existing = items.find((i) => i._id === medicine._id);
        if (existing) {
          set({ items: items.map((i) => i._id === medicine._id ? { ...i, quantity: i.quantity + quantity } : i) });
        } else {
          set({ items: [...items, { ...medicine, quantity }] });
        }
      },

      removeItem: (id) => set({ items: get().items.filter((i) => i._id !== id) }),

      updateQuantity: (id, quantity) => {
        if (quantity < 1) return get().removeItem(id);
        set({ items: get().items.map((i) => i._id === id ? { ...i, quantity } : i) });
      },

      clearCart: () => set({ items: [] }),

      get total() { return get().items.reduce((sum, i) => sum + i.finalPrice * i.quantity, 0); },
      get count() { return get().items.reduce((sum, i) => sum + i.quantity, 0); },
    }),
    { name: 'pharmaone-cart' }
  )
);
