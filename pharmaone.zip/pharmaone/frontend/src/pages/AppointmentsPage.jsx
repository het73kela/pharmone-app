// AppointmentsPage.jsx
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { FiCalendar, FiVideo, FiClock } from 'react-icons/fi';
import { MdSick } from 'react-icons/md';
import api from '../utils/api';

export default function AppointmentsPage() {
  const { data, isLoading } = useQuery({ queryKey: ['my-appointments'], queryFn: () => api.get('/appointments/my').then(r => r.data) });

  const statusColor = { Pending:'amber', Confirmed:'blue', InProgress:'teal', Completed:'emerald', Cancelled:'rose' };

  return (
    <div className="pt-20 page-container">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-9 h-9 bg-gradient-to-br from-rose-500 to-red-500 rounded-xl flex items-center justify-center">
          <MdSick className="text-white" />
        </div>
        <h1 className="section-title">My Appointments</h1>
        <Link to="/doctors" className="ml-auto btn-primary text-sm py-2 flex items-center gap-1.5"><FiCalendar /> Book New</Link>
      </div>

      {isLoading && <div className="space-y-4">{Array.from({length:3}).map((_,i) => <div key={i} className="card animate-pulse h-32" />)}</div>}

      {data?.appointments?.length === 0 && (
        <div className="text-center py-16 text-slate-600">
          <FiCalendar className="text-5xl mx-auto mb-3 opacity-30" />
          <p className="font-medium mb-4">No appointments yet</p>
          <Link to="/doctors" className="btn-primary text-sm">Book a Doctor</Link>
        </div>
      )}

      <div className="space-y-4">
        {data?.appointments?.map((appt) => {
          const c = statusColor[appt.status] || 'slate';
          return (
            <div key={appt._id} className="card">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-teal-700 to-cyan-700 rounded-xl flex items-center justify-center text-white font-bold overflow-hidden">
                    {appt.doctor?.avatar ? <img src={appt.doctor.avatar} alt="" className="w-full h-full object-cover" /> : appt.doctor?.name?.charAt(0)}
                  </div>
                  <div>
                    <p className="font-bold text-slate-200">{appt.doctor?.name}</p>
                    <p className="text-sm text-slate-400">{appt.doctor?.specialization}</p>
                  </div>
                </div>
                <span className={`badge bg-${c}-900/50 text-${c}-300 border border-${c}-700/50`}>{appt.status}</span>
              </div>

              <div className="flex flex-wrap gap-4 text-sm text-slate-400 mb-3">
                <span className="flex items-center gap-1.5"><FiClock /> {new Date(appt.date).toLocaleDateString('en-IN', { weekday:'short', day:'numeric', month:'short' })}</span>
                <span>{appt.slot?.start} – {appt.slot?.end}</span>
                <span className="flex items-center gap-1.5"><FiVideo /> {appt.type}</span>
                <span className="text-slate-300 font-medium">₹{appt.fee}</span>
              </div>

              {appt.symptoms && <p className="text-sm text-slate-500 mb-3">Symptoms: {appt.symptoms}</p>}

              {appt.status === 'Confirmed' && (
                <Link to={`/consultation/${appt.roomId}`}
                  className="btn-primary text-sm py-2 inline-flex items-center gap-1.5 mt-1">
                  <FiVideo /> Join Consultation
                </Link>
              )}
              {appt.notes && (
                <div className="mt-3 p-3 bg-slate-800/50 rounded-xl">
                  <p className="text-xs text-slate-400 font-medium mb-1">Doctor's Notes</p>
                  <p className="text-sm text-slate-300">{appt.notes}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
