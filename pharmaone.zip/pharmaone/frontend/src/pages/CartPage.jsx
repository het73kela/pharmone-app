import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FiShoppingCart, FiTrash2, FiPlus, FiMinus, FiArrowRight, FiPackage } from 'react-icons/fi';
import { MdLocalPharmacy } from 'react-icons/md';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { useCartStore } from '../context/cartStore';
import { useAuthStore } from '../context/authStore';

export default function CartPage() {
  const { items, removeItem, updateQuantity, clearCart, total } = useCartStore();
  const { token } = useAuthStore();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [address, setAddress] = useState({ name: '', phone: '', street: '', city: '', state: '', pincode: '' });

  const shippingFee = total >= 500 ? 0 : 40;
  const finalTotal = total + shippingFee;

  const handleCheckout = async () => {
    if (!token) return navigate('/login');
    if (!address.name || !address.street || !address.city || !address.pincode) return toast.error('Please fill in delivery address');

    setLoading(true);
    try {
      const { data } = await api.post('/orders', {
        items: items.map((i) => ({ medicineId: i._id, quantity: i.quantity })),
        shippingAddress: address,
        paymentMethod: 'COD',
      });
      clearCart();
      toast.success('Order placed successfully!');
      navigate('/orders');
    } catch (err) { toast.error(err.response?.data?.message || 'Order failed'); }
    finally { setLoading(false); }
  };

  if (items.length === 0) {
    return (
      <div className="pt-20 page-container flex flex-col items-center justify-center min-h-[60vh] text-center">
        <FiShoppingCart className="text-7xl text-slate-700 mb-6" />
        <h2 className="text-2xl font-bold text-slate-400 mb-2">Your cart is empty</h2>
        <p className="text-slate-500 mb-8">Add medicines to your cart to place an order.</p>
        <Link to="/medicines" className="btn-primary flex items-center gap-2">
          Browse Medicines <FiArrowRight />
        </Link>
      </div>
    );
  }

  return (
    <div className="pt-20 page-container">
      <div className="flex items-center gap-3 mb-8">
        <h1 className="section-title">Shopping Cart</h1>
        <span className="badge bg-teal-900/50 text-teal-300 border border-teal-800">{items.length} items</span>
        <button onClick={clearCart} className="ml-auto text-sm text-slate-500 hover:text-rose-400 transition-colors flex items-center gap-1">
          <FiTrash2 /> Clear cart
        </button>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Items */}
        <div className="lg:col-span-2 space-y-4">
          <AnimatePresence>
            {items.map((item) => (
              <motion.div key={item._id} layout exit={{ opacity: 0, x: -20 }} className="card flex items-center gap-4">
                <div className="w-16 h-16 bg-slate-800 rounded-xl flex items-center justify-center flex-shrink-0 overflow-hidden">
                  {item.images?.[0] ? <img src={item.images[0]} alt={item.name} className="w-full h-full object-cover rounded-xl" /> : <MdLocalPharmacy className="text-3xl text-slate-600" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-slate-200 truncate">{item.name}</p>
                  <p className="text-sm text-slate-500">{item.brand}</p>
                  <p className="text-sm font-bold text-teal-400 mt-1">₹{item.finalPrice?.toFixed(0)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => updateQuantity(item._id, item.quantity - 1)} className="w-7 h-7 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-colors">
                    <FiMinus className="text-xs" />
                  </button>
                  <span className="w-8 text-center text-sm font-bold">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item._id, item.quantity + 1)} className="w-7 h-7 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-colors">
                    <FiPlus className="text-xs" />
                  </button>
                </div>
                <div className="text-right">
                  <p className="font-bold text-slate-100">₹{(item.finalPrice * item.quantity).toFixed(0)}</p>
                  <button onClick={() => removeItem(item._id)} className="text-xs text-slate-600 hover:text-rose-400 transition-colors mt-1 flex items-center gap-0.5">
                    <FiTrash2 /> Remove
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Delivery address */}
          <div className="card">
            <h3 className="font-bold text-slate-200 mb-4 flex items-center gap-2"><FiPackage /> Delivery Address</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              {[
                { key: 'name', label: 'Full Name', placeholder: 'Recipient name' },
                { key: 'phone', label: 'Phone', placeholder: '10-digit number' },
                { key: 'street', label: 'Street Address', placeholder: 'House no., Street', span: true },
                { key: 'city', label: 'City', placeholder: 'City' },
                { key: 'state', label: 'State', placeholder: 'State' },
                { key: 'pincode', label: 'Pincode', placeholder: '6-digit pincode' },
              ].map(({ key, label, placeholder, span }) => (
                <div key={key} className={span ? 'sm:col-span-2' : ''}>
                  <label className="label">{label}</label>
                  <input value={address[key]} onChange={(e) => setAddress({ ...address, [key]: e.target.value })}
                    placeholder={placeholder} className="input" required />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Summary */}
        <div>
          <div className="card sticky top-24">
            <h3 className="font-bold text-slate-200 mb-5">Order Summary</h3>
            <div className="space-y-3 text-sm mb-5">
              <div className="flex justify-between text-slate-400"><span>Subtotal</span><span>₹{total.toFixed(0)}</span></div>
              <div className="flex justify-between text-slate-400">
                <span>Shipping</span>
                <span className={shippingFee === 0 ? 'text-emerald-400' : ''}>{shippingFee === 0 ? 'FREE' : `₹${shippingFee}`}</span>
              </div>
              {shippingFee > 0 && <p className="text-xs text-slate-600">Add ₹{(500 - total).toFixed(0)} more for free delivery</p>}
              <hr className="border-slate-800" />
              <div className="flex justify-between font-bold text-base text-slate-100">
                <span>Total</span><span>₹{finalTotal.toFixed(0)}</span>
              </div>
            </div>
            <button onClick={handleCheckout} disabled={loading} className="btn-primary w-full py-3 flex items-center justify-center gap-2">
              {loading ? <><div className="spinner" /> Placing order…</> : <><FiArrowRight /> Place Order (COD)</>}
            </button>
            <p className="text-xs text-slate-600 text-center mt-3">💳 Online payment coming soon</p>
          </div>
        </div>
      </div>
    </div>
  );
}
