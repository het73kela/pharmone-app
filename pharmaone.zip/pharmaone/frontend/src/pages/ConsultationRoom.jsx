import { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { io } from 'socket.io-client';
import { FiMic, FiMicOff, FiVideo, FiVideoOff, FiPhone, FiSend, FiMessageCircle } from 'react-icons/fi';
import { useAuthStore } from '../context/authStore';

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000';

export default function ConsultationRoom() {
  const { roomId } = useParams();
  const { user } = useAuthStore();
  const [socket, setSocket] = useState(null);
  const [localStream, setLocalStream] = useState(null);
  const [remoteStream, setRemoteStream] = useState(null);
  const [muted, setMuted] = useState(false);
  const [videoOff, setVideoOff] = useState(false);
  const [messages, setMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [chatOpen, setChatOpen] = useState(false);
  const [peerConnected, setPeerConnected] = useState(false);
  const localVideoRef = useRef();
  const remoteVideoRef = useRef();
  const pcRef = useRef();

  useEffect(() => {
    const s = io(SOCKET_URL);
    setSocket(s);

    const startMedia = async () => {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      setLocalStream(stream);
      if (localVideoRef.current) localVideoRef.current.srcObject = stream;

      const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
      pcRef.current = pc;

      stream.getTracks().forEach(track => pc.addTrack(track, stream));

      pc.ontrack = (e) => {
        setRemoteStream(e.streams[0]);
        if (remoteVideoRef.current) remoteVideoRef.current.srcObject = e.streams[0];
        setPeerConnected(true);
      };

      pc.onicecandidate = (e) => {
        if (e.candidate) s.emit('webrtc:ice-candidate', { roomId, candidate: e.candidate });
      };

      s.on('room:user-joined', async () => {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        s.emit('webrtc:offer', { roomId, offer, from: user._id });
      });

      s.on('webrtc:offer', async ({ offer }) => {
        await pc.setRemoteDescription(offer);
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        s.emit('webrtc:answer', { roomId, answer, from: user._id });
      });

      s.on('webrtc:answer', async ({ answer }) => {
        await pc.setRemoteDescription(answer);
      });

      s.on('webrtc:ice-candidate', async ({ candidate }) => {
        try { await pc.addIceCandidate(candidate); } catch (_) {}
      });

      s.on('chat:message', (msg) => setMessages(prev => [...prev, msg]));

      s.emit('user:online', user._id);
      s.emit('room:join', { roomId, userId: user._id, role: user.role });
    };

    startMedia();

    return () => {
      localStream?.getTracks().forEach(t => t.stop());
      pcRef.current?.close();
      s.emit('room:leave', { roomId, userId: user._id });
      s.disconnect();
    };
  }, [roomId]);

  const toggleMute = () => {
    localStream?.getAudioTracks().forEach(t => { t.enabled = !t.enabled; });
    setMuted(!muted);
  };
  const toggleVideo = () => {
    localStream?.getVideoTracks().forEach(t => { t.enabled = !t.enabled; });
    setVideoOff(!videoOff);
  };
  const endCall = () => {
    localStream?.getTracks().forEach(t => t.stop());
    window.close();
  };

  const sendMessage = () => {
    if (!chatInput.trim()) return;
    const msg = { message: chatInput, sender: user.name, timestamp: new Date().toISOString() };
    socket?.emit('chat:message', { roomId, ...msg });
    setMessages(prev => [...prev, msg]);
    setChatInput('');
  };

  return (
    <div className="pt-16 h-screen bg-slate-950 flex flex-col">
      {/* Video area */}
      <div className="flex-1 relative bg-slate-900">
        {/* Remote video (full) */}
        <video ref={remoteVideoRef} autoPlay playsInline className="w-full h-full object-cover" />
        {!peerConnected && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500">
            <div className="w-20 h-20 rounded-full bg-slate-800 flex items-center justify-center mb-4 animate-pulse">
              <FiVideo className="text-4xl" />
            </div>
            <p className="text-lg font-medium">Waiting for the other participant…</p>
            <p className="text-sm mt-1">Room: {roomId?.slice(0, 8)}…</p>
          </div>
        )}

        {/* Local video (PiP) */}
        <div className="absolute bottom-4 right-4 w-40 h-28 rounded-2xl overflow-hidden border-2 border-slate-800 shadow-2xl bg-slate-900">
          <video ref={localVideoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
          {videoOff && <div className="absolute inset-0 bg-slate-900 flex items-center justify-center"><span className="text-2xl font-bold text-white">{user?.name?.charAt(0)}</span></div>}
        </div>

        {/* Chat panel */}
        {chatOpen && (
          <div className="absolute top-4 right-4 w-72 h-80 glass rounded-2xl flex flex-col overflow-hidden">
            <p className="text-xs font-bold text-slate-300 px-4 py-3 border-b border-slate-800">In-consultation Chat</p>
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {messages.map((m, i) => (
                <div key={i} className={`text-xs ${m.sender === user.name ? 'text-right' : ''}`}>
                  <span className="text-slate-500">{m.sender}: </span>
                  <span className="text-slate-300">{m.message}</span>
                </div>
              ))}
            </div>
            <div className="flex gap-2 p-2 border-t border-slate-800">
              <input value={chatInput} onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="Type a message…" className="input text-xs py-1.5 flex-1" />
              <button onClick={sendMessage} className="bg-teal-600 hover:bg-teal-500 text-white w-8 h-8 rounded-xl flex items-center justify-center">
                <FiSend className="text-xs" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-4 px-6 py-5 bg-slate-900 border-t border-slate-800">
        <button onClick={toggleMute} className={`w-12 h-12 rounded-2xl flex items-center justify-center text-lg transition-all ${muted ? 'bg-rose-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'}`}>
          {muted ? <FiMicOff /> : <FiMic />}
        </button>
        <button onClick={toggleVideo} className={`w-12 h-12 rounded-2xl flex items-center justify-center text-lg transition-all ${videoOff ? 'bg-rose-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'}`}>
          {videoOff ? <FiVideoOff /> : <FiVideo />}
        </button>
        <button onClick={() => setChatOpen(!chatOpen)} className={`w-12 h-12 rounded-2xl flex items-center justify-center text-lg transition-all ${chatOpen ? 'bg-teal-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'}`}>
          <FiMessageCircle />
        </button>
        <button onClick={endCall} className="w-14 h-12 bg-rose-600 hover:bg-rose-500 text-white rounded-2xl flex items-center justify-center text-xl transition-all shadow-lg shadow-rose-500/30">
          <FiPhone className="rotate-135" />
        </button>
      </div>
    </div>
  );
}
