// DashboardPage.jsx
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { FiActivity, FiShoppingCart, FiCalendar, FiBook, FiBriefcase, FiArrowRight } from 'react-icons/fi';
import { MdSick } from 'react-icons/md';
import api from '../utils/api';
import { useAuthStore } from '../context/authStore';

export default function DashboardPage() {
  const { user } = useAuthStore();
  const { data: orders } = useQuery({ queryKey: ['my-orders'], queryFn: () => api.get('/orders/my').then(r => r.data) });
  const { data: appts } = useQuery({ queryKey: ['my-appointments'], queryFn: () => api.get('/appointments/my').then(r => r.data) });

  const cards = [
    { icon: FiShoppingCart, label: 'Total Orders', value: orders?.orders?.length || 0, link: '/orders', color: 'from-teal-500 to-emerald-500' },
    { icon: MdSick, label: 'Appointments', value: appts?.appointments?.length || 0, link: '/appointments', color: 'from-rose-500 to-red-500' },
    { icon: FiBook, label: 'Browse Notes', value: 'Study →', link: '/notes', color: 'from-blue-500 to-cyan-500' },
    { icon: FiBriefcase, label: 'Find Jobs', value: 'Explore →', link: '/jobs', color: 'from-indigo-500 to-violet-500' },
  ];

  return (
    <div className="pt-20 page-container">
      <div className="mb-8">
        <h1 className="section-title mb-1">Welcome back, {user?.name?.split(' ')[0]} 👋</h1>
        <p className="text-slate-400 capitalize">{user?.role} Account · {user?.email}</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
        {cards.map(({ icon: Icon, label, value, link, color }) => (
          <Link key={link} to={link} className="card hover:border-slate-700 hover:-translate-y-0.5 transition-all group">
            <div className={`w-10 h-10 bg-gradient-to-br ${color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
              <Icon className="text-white text-lg" />
            </div>
            <p className="text-2xl font-extrabold text-slate-100">{value}</p>
            <p className="text-sm text-slate-400 mt-0.5">{label}</p>
          </Link>
        ))}
      </div>

      {/* Recent orders */}
      <div className="card">
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-bold text-slate-200">Recent Orders</h2>
          <Link to="/orders" className="text-sm text-teal-400 hover:text-teal-300 flex items-center gap-1">View all <FiArrowRight /></Link>
        </div>
        {orders?.orders?.length === 0 && <p className="text-slate-500 text-sm">No orders yet.</p>}
        <div className="space-y-3">
          {orders?.orders?.slice(0, 5).map((order) => (
            <div key={order._id} className="flex items-center justify-between py-3 border-b border-slate-800 last:border-0">
              <div>
                <p className="text-sm font-medium text-slate-300">Order #{order._id.slice(-6).toUpperCase()}</p>
                <p className="text-xs text-slate-500">{new Date(order.createdAt).toLocaleDateString('en-IN')} · {order.items.length} items</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-slate-200">₹{order.total}</p>
                <span className={`badge text-[10px] ${
                  order.orderStatus === 'Delivered' ? 'bg-emerald-900/50 text-emerald-300 border border-emerald-700/50' :
                  order.orderStatus === 'Cancelled' ? 'bg-rose-900/50 text-rose-300 border border-rose-700/50' :
                  'bg-amber-900/50 text-amber-300 border border-amber-700/50'}`}>
                  {order.orderStatus}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
