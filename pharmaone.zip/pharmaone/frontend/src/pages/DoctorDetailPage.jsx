import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { FiArrowLeft, FiStar, FiClock, FiVideo } from 'react-icons/fi';
import { MdVerified } from 'react-icons/md';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { useAuthStore } from '../context/authStore';

export default function DoctorDetailPage() {
  const { id } = useParams();
  const { token } = useAuthStore();
  const navigate = useNavigate();
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [selectedDay, setSelectedDay] = useState(null);
  const [booking, setBooking] = useState(false);
  const [symptoms, setSymptoms] = useState('');

  const { data, isLoading } = useQuery({ queryKey: ['doctor', id], queryFn: () => api.get(`/doctors/${id}`).then(r => r.data) });
  const doc = data?.doctor;

  const handleBook = async () => {
    if (!token) { toast.error('Please login to book'); return navigate('/login'); }
    if (!selectedSlot || !selectedDay) return toast.error('Please select a time slot');
    setBooking(true);
    try {
      const today = new Date();
      const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
      let date = new Date(today);
      while (days[date.getDay()] !== selectedDay) date.setDate(date.getDate() + 1);
      await api.post('/appointments', { doctorId: id, date: date.toISOString(), slot: selectedSlot, type: 'Video', symptoms });
      toast.success('Appointment booked!');
      navigate('/appointments');
    } catch (err) { toast.error(err.response?.data?.message || 'Booking failed'); }
    finally { setBooking(false); }
  };

  if (isLoading) return <div className="pt-20 page-container"><div className="card animate-pulse h-80" /></div>;
  if (!doc) return <div className="pt-20 page-container text-slate-500">Doctor not found.</div>;

  return (
    <div className="pt-20 page-container">
      <Link to="/doctors" className="btn-ghost inline-flex items-center gap-2 mb-6 text-sm"><FiArrowLeft /> Back to Doctors</Link>
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="card mb-6">
            <div className="flex items-start gap-5">
              <div className="w-24 h-24 bg-gradient-to-br from-teal-600 to-cyan-600 rounded-2xl flex items-center justify-center text-4xl font-bold text-white overflow-hidden flex-shrink-0">
                {doc.avatar ? <img src={doc.avatar} alt={doc.name} className="w-full h-full object-cover" /> : doc.name?.charAt(0)}
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h1 className="text-2xl font-extrabold text-slate-100">{doc.name}</h1>
                  {doc.isVerified && <MdVerified className="text-teal-400 text-xl" />}
                </div>
                <p className="text-slate-400 mb-1">{doc.specialization}</p>
                <p className="text-sm text-slate-500 mb-3">{doc.qualification} · {doc.experience} years experience</p>
                <div className="flex items-center gap-4 text-sm">
                  <span className="flex items-center gap-1.5"><FiStar className="text-amber-400" />{doc.rating?.toFixed(1)} ({doc.totalReviews})</span>
                  <span className="text-slate-300 font-bold">₹{doc.consultationFee} / session</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Booking */}
        <div className="card h-fit sticky top-24">
          <h3 className="font-bold text-slate-200 mb-5 flex items-center gap-2"><FiVideo /> Book Consultation</h3>
          {doc.availability?.map((av) => (
            <div key={av.day} className="mb-4">
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">{av.day}</p>
              <div className="flex flex-wrap gap-2">
                {av.slots.map((slot, i) => (
                  <button key={i} onClick={() => { setSelectedDay(av.day); setSelectedSlot(slot); }}
                    className={`text-xs px-3 py-1.5 rounded-xl border transition-all font-medium ${selectedDay === av.day && selectedSlot?.start === slot.start ? 'border-teal-500 bg-teal-900/40 text-teal-300' : 'border-slate-700 text-slate-400 hover:border-teal-600 hover:text-teal-400'}`}>
                    {slot.start}
                  </button>
                ))}
              </div>
            </div>
          ))}
          <div className="mt-4">
            <label className="label">Symptoms (optional)</label>
            <textarea value={symptoms} onChange={e => setSymptoms(e.target.value)} className="input resize-none h-20 text-sm" placeholder="Describe your symptoms…" />
          </div>
          <button onClick={handleBook} disabled={booking || !selectedSlot} className="btn-primary w-full mt-4 flex items-center justify-center gap-2">
            {booking ? <><div className="spinner" /> Booking…</> : 'Book Appointment'}
          </button>
        </div>
      </div>
    </div>
  );
}
