import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { FiSearch, FiStar, FiClock, FiVideo } from 'react-icons/fi';
import { MdSick, MdVerified } from 'react-icons/md';
import api from '../utils/api';

const SPECS = ['All', 'Clinical Pharmacist', 'General Physician', 'Dermatologist', 'Cardiologist', 'Endocrinologist', 'Pulmonologist'];

export default function DoctorsPage() {
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [specialization, setSpecialization] = useState('');
  const [page, setPage] = useState(1);

  const { data, isLoading } = useQuery({
    queryKey: ['doctors', search, specialization, page],
    queryFn: () => api.get('/doctors', { params: { search: search || undefined, specialization: specialization || undefined, page } }).then((r) => r.data),
  });

  const handleSearch = (e) => { e.preventDefault(); setSearch(searchInput); setPage(1); };

  return (
    <div className="pt-20 page-container">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-9 h-9 bg-gradient-to-br from-rose-500 to-red-500 rounded-xl flex items-center justify-center">
            <MdSick className="text-white text-lg" />
          </div>
          <h1 className="section-title">Online Doctor Visits</h1>
        </div>
        <p className="text-slate-400">Book a video consultation with verified doctors and clinical pharmacists. Get prescriptions online.</p>
      </div>

      {/* Search */}
      <form onSubmit={handleSearch} className="flex gap-3 mb-6">
        <div className="relative flex-1">
          <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
          <input value={searchInput} onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search by doctor name or specialization…"
            className="input pl-11 h-12" />
        </div>
        <button type="submit" className="btn-primary h-12 px-6">Search</button>
      </form>

      {/* Specialization filter */}
      <div className="flex flex-wrap gap-2 mb-8">
        {SPECS.map((spec) => (
          <button key={spec} onClick={() => { setSpecialization(spec === 'All' ? '' : spec); setPage(1); }}
            className={`chip ${(specialization === spec || (spec === 'All' && !specialization)) ? 'chip-active' : ''}`}>
            {spec}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="card animate-pulse h-52">
              <div className="flex gap-4 mb-4">
                <div className="w-16 h-16 rounded-2xl bg-slate-800 flex-shrink-0" />
                <div className="flex-1"><div className="bg-slate-800 h-4 rounded w-3/4 mb-2" /><div className="bg-slate-800 h-3 rounded w-1/2" /></div>
              </div>
              <div className="bg-slate-800 h-3 rounded mb-2" /><div className="bg-slate-800 h-3 rounded w-2/3" />
            </div>
          ))}
        </div>
      ) : (
        <motion.div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {data?.doctors?.map((doc, i) => (
            <motion.div key={doc._id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Link to={`/doctors/${doc._id}`} className="card block group hover:border-slate-700 hover:-translate-y-1 transition-all duration-200 h-full">
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-teal-700 to-cyan-700 rounded-2xl flex-shrink-0 flex items-center justify-center text-2xl font-bold text-white overflow-hidden shadow-lg">
                    {doc.avatar ? <img src={doc.avatar} alt={doc.name} className="w-full h-full object-cover" /> : doc.name?.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <p className="font-bold text-slate-100 group-hover:text-teal-400 transition-colors truncate">{doc.name}</p>
                      {doc.isVerified && <MdVerified className="text-teal-400 flex-shrink-0" />}
                    </div>
                    <p className="text-sm text-slate-400">{doc.specialization}</p>
                    <p className="text-xs text-slate-500">{doc.qualification}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm mb-4">
                  <div className="flex items-center gap-1.5">
                    <FiStar className="text-amber-400" />
                    <span className="text-slate-300 font-semibold">{doc.rating?.toFixed(1)}</span>
                    <span className="text-slate-500">({doc.totalReviews})</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-400">
                    <FiClock className="text-slate-500" />
                    <span>{doc.experience} yrs exp.</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                  <div>
                    <span className="text-lg font-bold text-slate-100">₹{doc.consultationFee || 500}</span>
                    <span className="text-xs text-slate-500 ml-1">/consultation</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-teal-900/40 border border-teal-800/50 text-teal-300 text-xs font-medium px-3 py-1.5 rounded-xl">
                    <FiVideo className="text-xs" /> Book Now
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      )}

      {!isLoading && data?.doctors?.length === 0 && (
        <div className="text-center py-16 text-slate-600">
          <MdSick className="text-5xl mx-auto mb-3 opacity-30" />
          <p className="font-medium">No doctors found</p>
        </div>
      )}
    </div>
  );
}
