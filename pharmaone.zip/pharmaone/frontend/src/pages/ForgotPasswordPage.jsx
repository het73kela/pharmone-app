import { useState } from 'react';
import { Link } from 'react-router-dom';
import { FiMail, FiArrowLeft } from 'react-icons/fi';
import toast from 'react-hot-toast';
import api from '../utils/api';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post('/auth/forgot-password', { email });
      setSent(true);
      toast.success('Reset email sent!');
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to send email'); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen pt-16 flex items-center justify-center px-4">
      <div className="w-full max-w-md card shadow-2xl shadow-black/50">
        <Link to="/login" className="btn-ghost inline-flex items-center gap-1.5 text-sm mb-6"><FiArrowLeft /> Back to login</Link>
        <h1 className="text-xl font-extrabold text-slate-100 mb-2">Forgot Password?</h1>
        <p className="text-slate-400 text-sm mb-6">Enter your email and we'll send a reset link.</p>
        {sent ? (
          <div className="text-center py-6">
            <div className="w-14 h-14 bg-teal-900/50 border border-teal-700 rounded-2xl flex items-center justify-center mx-auto mb-4"><FiMail className="text-teal-400 text-2xl" /></div>
            <p className="font-semibold text-slate-200 mb-1">Email sent!</p>
            <p className="text-sm text-slate-400">Check your inbox for the reset link.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Email address</label>
              <div className="relative"><FiMail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="input pl-11" placeholder="you@example.com" required /></div>
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
              {loading ? <><div className="spinner" /> Sending…</> : 'Send Reset Link'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
