import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiArrowRight, FiBook, FiVideo, FiSearch, FiBriefcase, FiShield, FiZap, FiActivity } from 'react-icons/fi';
import { MdLocalPharmacy, MdSick } from 'react-icons/md';

const features = [
  { icon: MdLocalPharmacy, color: 'from-teal-500 to-emerald-500', title: 'Medicine Ordering', desc: 'Browse 10,000+ medicines. Order with doorstep delivery. Prescription upload supported.', link: '/medicines', tag: 'Delivery in 2-4 hrs' },
  { icon: FiBook, color: 'from-blue-500 to-cyan-500', title: 'eNotes & PDFs', desc: 'Curated pharmacy notes across all subjects and years. Upload and share with classmates.', link: '/notes', tag: '5,000+ resources' },
  { icon: FiVideo, color: 'from-purple-500 to-pink-500', title: 'Video Lectures', desc: 'Expert-taught video lessons on Pharmacology, Pharmaceutics, and more.', link: '/lectures', tag: 'HD Quality' },
  { icon: FiSearch, color: 'from-amber-500 to-orange-500', title: 'AI Research Analyzer', desc: 'Upload any research paper. Our AI summarizes, finds key findings, and explains methodology.', link: '/research', tag: 'GPT-4o Powered' },
  { icon: MdSick, color: 'from-rose-500 to-red-500', title: 'Online Doctor Visits', desc: 'Book video consultations with verified clinical pharmacists and doctors. Prescriptions included.', link: '/doctors', tag: 'Available 24/7' },
  { icon: FiBriefcase, color: 'from-indigo-500 to-violet-500', title: 'Jobs & Internships', desc: 'Pharmacy careers — hospital roles, research positions, industrial internships, and more.', link: '/jobs', tag: '500+ listings' },
];

const stats = [
  { value: '50,000+', label: 'Active Students' },
  { value: '10,000+', label: 'Medicines Available' },
  { value: '500+', label: 'Verified Doctors' },
  { value: '5,000+', label: 'Study Resources' },
];

const container = { hidden: {}, show: { transition: { staggerChildren: 0.08 } } };
const item = { hidden: { opacity: 0, y: 24 }, show: { opacity: 1, y: 0, transition: { duration: 0.4 } } };

export default function HomePage() {
  return (
    <div className="pt-16">
      {/* Hero */}
      <section className="relative overflow-hidden min-h-[90vh] flex items-center">
        {/* Background effects */}
        <div className="absolute inset-0 bg-slate-950">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl animate-pulse-slow" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-cyan-500/8 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '1.5s' }} />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-teal-900/20 rounded-full blur-3xl" />
        </div>

        {/* Grid pattern */}
        <div className="absolute inset-0 opacity-[0.03]"
          style={{ backgroundImage: 'linear-gradient(#0d9488 1px, transparent 1px), linear-gradient(90deg, #0d9488 1px, transparent 1px)', backgroundSize: '60px 60px' }} />

        <div className="relative page-container text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-flex items-center gap-2 bg-teal-900/40 border border-teal-800/60 text-teal-300 text-sm font-medium px-4 py-2 rounded-full mb-8">
              <FiZap className="text-teal-400" />
              India's First All-in-One Pharmacy Super App
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-slate-100 leading-tight mb-6">
              Everything Pharmacy,
              <br />
              <span className="gradient-text">One Platform</span>
            </h1>

            <p className="text-xl text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed">
              Order medicines, study smarter, consult doctors, analyze research papers, and launch your pharmacy career — all powered by AI.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
              <Link to="/medicines" className="btn-primary text-base px-8 py-3.5 flex items-center justify-center gap-2 group shadow-lg shadow-teal-500/20">
                Get Started Free <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link to="/doctors" className="btn-secondary text-base px-8 py-3.5 flex items-center justify-center gap-2">
                Book a Doctor
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-3xl mx-auto">
              {stats.map((stat, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 + i * 0.1 }}
                  className="card text-center">
                  <p className="text-2xl font-extrabold gradient-text">{stat.value}</p>
                  <p className="text-xs text-slate-500 mt-1 font-medium">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="page-container py-20">
        <div className="text-center mb-14">
          <h2 className="text-4xl font-extrabold text-slate-100 mb-4">Everything You Need</h2>
          <p className="text-slate-400 text-lg max-w-xl mx-auto">Six powerful modules designed for pharmacy students, professionals, and patients.</p>
        </div>

        <motion.div variants={container} initial="hidden" whileInView="show" viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map(({ icon: Icon, color, title, desc, link, tag }, i) => (
            <motion.div key={i} variants={item}>
              <Link to={link} className="card block group hover:border-slate-700 hover:-translate-y-1 transition-all duration-300 h-full">
                <div className={`w-12 h-12 bg-gradient-to-br ${color} rounded-2xl flex items-center justify-center mb-5 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="text-white text-xl" />
                </div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <h3 className="text-lg font-bold text-slate-100 group-hover:text-teal-400 transition-colors">{title}</h3>
                  <span className="badge bg-slate-800 text-slate-400 text-[10px] flex-shrink-0 border border-slate-700">{tag}</span>
                </div>
                <p className="text-slate-400 text-sm leading-relaxed">{desc}</p>
                <div className="flex items-center gap-1.5 mt-5 text-teal-500 text-sm font-medium group-hover:gap-2.5 transition-all">
                  Explore <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* AI Banner */}
      <section className="page-container py-10 mb-10">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
          className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-teal-900/60 to-cyan-900/40 border border-teal-800/50 p-10 text-center">
          <div className="absolute inset-0 opacity-5"
            style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, #0d9488 1px, transparent 0)', backgroundSize: '32px 32px' }} />
          <div className="relative">
            <div className="w-16 h-16 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-teal-500/40 animate-float">
              <FiZap className="text-white text-3xl" />
            </div>
            <h2 className="text-3xl font-extrabold text-slate-100 mb-3">Meet PharmaBot</h2>
            <p className="text-slate-400 max-w-lg mx-auto mb-6">Your AI navigator guides you to exactly what you need. Just describe your situation and PharmaBot handles the rest.</p>
            <div className="flex flex-wrap gap-2 justify-center">
              {['Find me a fever medicine', 'Book a doctor for tomorrow', 'Explain this research paper', 'Pharmacy jobs in Mumbai'].map((ex) => (
                <span key={ex} className="chip text-sm">{ex}</span>
              ))}
            </div>
            <p className="mt-6 text-teal-400 text-sm font-medium">↘ Tap the chat button at the bottom right</p>
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 py-10">
        <div className="page-container flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-lg flex items-center justify-center">
              <FiActivity className="text-white text-xs" />
            </div>
            <span className="font-bold text-slate-300"><span className="gradient-text">Pharma</span>One</span>
          </div>
          <p className="text-slate-600 text-sm">© 2024 PharmaOne. Built for pharmacy professionals.</p>
          <div className="flex gap-4 text-sm">
            <Link to="/medicines" className="text-slate-500 hover:text-teal-400 transition-colors">Medicines</Link>
            <Link to="/doctors" className="text-slate-500 hover:text-teal-400 transition-colors">Doctors</Link>
            <Link to="/jobs" className="text-slate-500 hover:text-teal-400 transition-colors">Jobs</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
