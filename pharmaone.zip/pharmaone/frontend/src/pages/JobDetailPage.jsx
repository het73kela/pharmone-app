import { useState, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { FiArrowLeft, FiBriefcase, FiMapPin, FiClock, FiUpload } from 'react-icons/fi';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { useAuthStore } from '../context/authStore';

export default function JobDetailPage() {
  const { id } = useParams();
  const { token } = useAuthStore();
  const navigate = useNavigate();
  const [showApply, setShowApply] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');
  const [resumeFile, setResumeFile] = useState(null);
  const [applying, setApplying] = useState(false);
  const fileRef = useRef();

  const { data, isLoading } = useQuery({ queryKey: ['job', id], queryFn: () => api.get(`/jobs/${id}`).then(r => r.data) });
  const job = data?.job;

  const handleApply = async (e) => {
    e.preventDefault();
    if (!token) { toast.error('Please login to apply'); return navigate('/login'); }
    if (!resumeFile) return toast.error('Please upload your resume');
    const formData = new FormData();
    formData.append('resume', resumeFile);
    formData.append('coverLetter', coverLetter);
    setApplying(true);
    try {
      await api.post(`/jobs/${id}/apply`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success('Application submitted!');
      setShowApply(false);
    } catch (err) { toast.error(err.response?.data?.message || 'Application failed'); }
    finally { setApplying(false); }
  };

  if (isLoading) return <div className="pt-20 page-container"><div className="card animate-pulse h-80" /></div>;
  if (!job) return <div className="pt-20 page-container text-slate-500">Job not found.</div>;

  return (
    <div className="pt-20 page-container">
      <Link to="/jobs" className="btn-ghost inline-flex items-center gap-2 mb-6 text-sm"><FiArrowLeft /> Back to Jobs</Link>
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="card">
            <div className="flex items-start gap-4 mb-5">
              <div className="w-14 h-14 bg-gradient-to-br from-indigo-700 to-violet-700 rounded-xl flex items-center justify-center text-2xl font-bold text-white flex-shrink-0">{job.company?.charAt(0)}</div>
              <div>
                <h1 className="text-xl font-extrabold text-slate-100">{job.title}</h1>
                <p className="text-slate-400">{job.company}</p>
                <div className="flex flex-wrap gap-2 mt-2 text-xs">
                  <span className="chip chip-active">{job.type}</span>
                  <span className="flex items-center gap-1 text-slate-500"><FiMapPin /> {job.location}</span>
                  <span className="text-slate-500">{job.locationType}</span>
                  {job.salaryMin && <span className="text-emerald-400 font-semibold">₹{(job.salaryMin/1000).toFixed(0)}K–{(job.salaryMax/1000).toFixed(0)}K/mo</span>}
                </div>
              </div>
            </div>
            <p className="text-slate-300 text-sm leading-relaxed">{job.description}</p>
          </div>
          {job.requirements?.length > 0 && (
            <div className="card">
              <h3 className="font-bold text-slate-200 mb-3">Requirements</h3>
              <ul className="space-y-2">{job.requirements.map((r, i) => <li key={i} className="text-sm text-slate-300 flex items-start gap-2"><span className="text-teal-400 mt-0.5">•</span>{r}</li>)}</ul>
            </div>
          )}
        </div>
        <div>
          <div className="card sticky top-24">
            <button onClick={() => setShowApply(!showApply)} className="btn-primary w-full flex items-center justify-center gap-2 mb-4"><FiBriefcase /> Apply Now</button>
            {job.deadline && <p className="text-xs text-slate-500 text-center flex items-center justify-center gap-1"><FiClock /> Deadline: {new Date(job.deadline).toLocaleDateString('en-IN')}</p>}
            {showApply && (
              <form onSubmit={handleApply} className="mt-5 pt-5 border-t border-slate-800 space-y-4">
                <div>
                  <label className="label">Resume (PDF)</label>
                  <input type="file" accept=".pdf" ref={fileRef} onChange={e => setResumeFile(e.target.files[0])} className="input py-2.5 text-sm" required />
                </div>
                <div>
                  <label className="label">Cover Letter (optional)</label>
                  <textarea value={coverLetter} onChange={e => setCoverLetter(e.target.value)} className="input resize-none h-28 text-sm" placeholder="Why are you a great fit for this role?" />
                </div>
                <button type="submit" disabled={applying} className="btn-primary w-full flex items-center justify-center gap-2">
                  {applying ? <><div className="spinner" />Submitting…</> : <><FiUpload /> Submit Application</>}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
