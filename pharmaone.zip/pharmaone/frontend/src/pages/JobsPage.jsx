import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { FiSearch, FiBriefcase, FiMapPin, FiClock, FiArrowRight, FiBookmark } from 'react-icons/fi';
import { MdLocationOn } from 'react-icons/md';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { useAuthStore } from '../context/authStore';

const JOB_TYPES = ['All', 'Full-time', 'Part-time', 'Internship', 'Contract', 'Residency', 'Fellowship'];
const LOCATION_TYPES = ['All', 'Remote', 'On-site', 'Hybrid'];

const typeColors = {
  'Full-time': 'bg-emerald-900/50 text-emerald-300 border-emerald-700/50',
  'Internship': 'bg-blue-900/50 text-blue-300 border-blue-700/50',
  'Remote': 'bg-violet-900/50 text-violet-300 border-violet-700/50',
  'Residency': 'bg-amber-900/50 text-amber-300 border-amber-700/50',
  'Contract': 'bg-rose-900/50 text-rose-300 border-rose-700/50',
};

export default function JobsPage() {
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [type, setType] = useState('');
  const [locationType, setLocationType] = useState('');
  const [page, setPage] = useState(1);
  const { token } = useAuthStore();

  const { data, isLoading } = useQuery({
    queryKey: ['jobs', search, type, locationType, page],
    queryFn: () => api.get('/jobs', { params: { search: search || undefined, type: type || undefined, locationType: locationType || undefined, page } }).then((r) => r.data),
  });

  const handleSearch = (e) => { e.preventDefault(); setSearch(searchInput); setPage(1); };

  const handleSave = async (jobId, e) => {
    e.preventDefault();
    if (!token) return toast.error('Please login to save jobs');
    try {
      const { data: res } = await api.post(`/jobs/${jobId}/save`);
      toast.success(res.saved ? 'Job saved!' : 'Job removed from saved');
    } catch { toast.error('Failed to save job'); }
  };

  return (
    <div className="pt-20 page-container">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-9 h-9 bg-gradient-to-br from-indigo-500 to-violet-500 rounded-xl flex items-center justify-center">
            <FiBriefcase className="text-white text-lg" />
          </div>
          <h1 className="section-title">Pharmacy Jobs & Internships</h1>
        </div>
        <p className="text-slate-400">Discover 500+ pharmacy career opportunities — hospital roles, research, manufacturing, regulatory, and more.</p>
      </div>

      {/* Search */}
      <form onSubmit={handleSearch} className="flex gap-3 mb-5">
        <div className="relative flex-1">
          <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
          <input value={searchInput} onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search job title, company, or skills…"
            className="input pl-11 h-12" />
        </div>
        <button type="submit" className="btn-primary h-12 px-6">Search</button>
      </form>

      {/* Filters */}
      <div className="space-y-3 mb-8">
        <div className="flex flex-wrap gap-2">
          <span className="text-xs text-slate-500 font-medium pt-1.5">Type:</span>
          {JOB_TYPES.map((t) => (
            <button key={t} onClick={() => { setType(t === 'All' ? '' : t); setPage(1); }}
              className={`chip ${(type === t || (t === 'All' && !type)) ? 'chip-active' : ''}`}>{t}</button>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          <span className="text-xs text-slate-500 font-medium pt-1.5">Mode:</span>
          {LOCATION_TYPES.map((lt) => (
            <button key={lt} onClick={() => { setLocationType(lt === 'All' ? '' : lt); setPage(1); }}
              className={`chip ${(locationType === lt || (lt === 'All' && !locationType)) ? 'chip-active' : ''}`}>{lt}</button>
          ))}
        </div>
      </div>

      {data && <p className="text-sm text-slate-500 mb-5">{data.total} positions found</p>}

      {isLoading ? (
        <div className="space-y-4">
          {Array.from({ length: 5 }).map((_, i) => <div key={i} className="card animate-pulse h-28"><div className="bg-slate-800 h-full rounded-xl" /></div>)}
        </div>
      ) : (
        <div className="space-y-4">
          {data?.jobs?.map((job, i) => (
            <motion.div key={job._id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
              <Link to={`/jobs/${job._id}`}
                className="card flex items-start gap-4 group hover:border-slate-700 transition-all duration-200">
                {/* Company logo */}
                <div className="w-12 h-12 bg-gradient-to-br from-indigo-700 to-violet-700 rounded-xl flex items-center justify-center text-white font-bold text-lg flex-shrink-0 overflow-hidden shadow-md">
                  {job.companyLogo ? <img src={job.companyLogo} alt={job.company} className="w-full h-full object-cover" /> : job.company?.charAt(0)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="font-bold text-slate-100 group-hover:text-indigo-400 transition-colors">{job.title}</h3>
                      <p className="text-sm text-slate-400">{job.company}</p>
                    </div>
                    <button onClick={(e) => handleSave(job._id, e)} className="text-slate-600 hover:text-amber-400 transition-colors flex-shrink-0">
                      <FiBookmark className="text-lg" />
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 mt-2">
                    <span className={`badge border text-xs ${typeColors[job.type] || 'bg-slate-800 text-slate-400 border-slate-700'}`}>{job.type}</span>
                    <span className={`badge border text-xs ${typeColors[job.locationType] || 'bg-slate-800 text-slate-400 border-slate-700'}`}>{job.locationType}</span>
                    <span className="flex items-center gap-1 text-xs text-slate-500">
                      <MdLocationOn className="text-slate-600" /> {job.location}
                    </span>
                    {job.salaryMin && (
                      <span className="text-xs text-emerald-400 font-semibold">
                        ₹{(job.salaryMin / 1000).toFixed(0)}K–{(job.salaryMax / 1000).toFixed(0)}K/mo
                      </span>
                    )}
                    {job.deadline && (
                      <span className="flex items-center gap-1 text-xs text-slate-500">
                        <FiClock /> Deadline: {new Date(job.deadline).toLocaleDateString('en-IN')}
                      </span>
                    )}
                  </div>
                </div>

                <FiArrowRight className="text-slate-600 group-hover:text-indigo-400 flex-shrink-0 mt-1 group-hover:translate-x-1 transition-all" />
              </Link>
            </motion.div>
          ))}
        </div>
      )}

      {!isLoading && data?.jobs?.length === 0 && (
        <div className="text-center py-16 text-slate-600">
          <FiBriefcase className="text-5xl mx-auto mb-3 opacity-30" />
          <p className="font-medium">No jobs found matching your criteria</p>
        </div>
      )}

      {data?.pages > 1 && (
        <div className="flex justify-center gap-2 mt-10">
          {Array.from({ length: data.pages }).map((_, i) => (
            <button key={i} onClick={() => setPage(i + 1)}
              className={`w-10 h-10 rounded-xl text-sm font-medium transition-all ${page === i + 1 ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
