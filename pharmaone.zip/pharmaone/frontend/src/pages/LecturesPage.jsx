// LecturesPage.jsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { FiSearch, FiVideo, FiPlay, FiHeart, FiEye, FiClock } from 'react-icons/fi';
import api from '../utils/api';
import { useAuthStore } from '../context/authStore';

const SUBJECTS = ['All', 'Pharmacology', 'Pharmaceutics', 'Clinical Pharmacy', 'Pharmaceutical Chemistry', 'Pharmacognosy'];

export default function LecturesPage() {
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [subject, setSubject] = useState('');
  const [active, setActive] = useState(null);
  const { token } = useAuthStore();

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['lectures', search, subject],
    queryFn: () => api.get('/lectures', { params: { search: search || undefined, subject: subject || undefined } }).then((r) => r.data),
  });

  const handleSearch = (e) => { e.preventDefault(); setSearch(searchInput); };

  const handleLike = async (id) => {
    if (!token) return;
    await api.post(`/lectures/${id}/like`);
    refetch();
  };

  return (
    <div className="pt-20 page-container">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-9 h-9 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
          <FiVideo className="text-white text-lg" />
        </div>
        <h1 className="text-2xl font-bold text-slate-100">Video Lectures</h1>
      </div>
      <p className="text-slate-400 mb-8">Expert pharmacy lectures covering all major subjects.</p>

      <form onSubmit={handleSearch} className="flex gap-3 mb-5">
        <div className="relative flex-1">
          <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
          <input value={searchInput} onChange={(e) => setSearchInput(e.target.value)} placeholder="Search lectures…" className="input pl-11 h-12" />
        </div>
        <button type="submit" className="btn-primary h-12 px-6">Search</button>
      </form>

      <div className="flex flex-wrap gap-2 mb-8">
        {SUBJECTS.map((s) => (
          <button key={s} onClick={() => setSubject(s === 'All' ? '' : s)}
            className={`chip ${(subject === s || (s === 'All' && !subject)) ? 'chip-active' : ''}`}>{s}</button>
        ))}
      </div>

      {active && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="card mb-8 border-purple-800/30">
          <div className="aspect-video rounded-xl overflow-hidden bg-black mb-4">
            <iframe src={active.videoUrl} className="w-full h-full" allowFullScreen title={active.title} />
          </div>
          <h2 className="text-lg font-bold text-slate-100 mb-1">{active.title}</h2>
          <p className="text-sm text-slate-400">{active.instructor} · {active.duration} · {active.subject}</p>
          <button onClick={() => setActive(null)} className="mt-3 text-xs text-slate-500 hover:text-slate-300">Close player</button>
        </motion.div>
      )}

      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="card animate-pulse h-52"><div className="bg-slate-800 h-full rounded-xl" /></div>)}
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {data?.lectures?.map((lec, i) => (
            <motion.div key={lec._id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
              className="card group hover:border-slate-700 hover:-translate-y-0.5 transition-all duration-200">
              <div className="bg-gradient-to-br from-purple-900/40 to-pink-900/30 rounded-xl h-32 flex items-center justify-center mb-4 relative cursor-pointer"
                onClick={() => setActive(lec)}>
                <div className="w-12 h-12 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-all">
                  <FiPlay className="text-white text-xl ml-1" />
                </div>
                {lec.isFeatured && (
                  <span className="absolute top-2 left-2 badge bg-purple-900/80 text-purple-300 border border-purple-700/50 text-[10px]">Featured</span>
                )}
                <span className="absolute bottom-2 right-2 flex items-center gap-1 text-xs text-white/70 bg-black/50 px-2 py-0.5 rounded-full">
                  <FiClock className="text-xs" /> {lec.duration}
                </span>
              </div>
              <h3 className="text-sm font-semibold text-slate-200 group-hover:text-purple-400 transition-colors mb-1 line-clamp-2 cursor-pointer"
                onClick={() => setActive(lec)}>{lec.title}</h3>
              <p className="text-xs text-slate-500 mb-3">{lec.instructor} · {lec.subject}</p>
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="flex items-center gap-1"><FiEye /> {lec.views}</span>
                <button onClick={() => handleLike(lec._id)} className="flex items-center gap-1 hover:text-rose-400 transition-colors">
                  <FiHeart /> {lec.likes?.length || 0}
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
