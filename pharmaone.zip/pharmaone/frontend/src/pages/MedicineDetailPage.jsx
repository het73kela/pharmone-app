import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { FiShoppingCart, FiStar, FiArrowLeft, FiCheckCircle } from 'react-icons/fi';
import { MdLocalPharmacy } from 'react-icons/md';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { useCartStore } from '../context/cartStore';

export default function MedicineDetailPage() {
  const { id } = useParams();
  const addItem = useCartStore(s => s.addItem);
  const { data, isLoading } = useQuery({ queryKey: ['medicine', id], queryFn: () => api.get(`/medicines/${id}`).then(r => r.data) });
  const med = data?.medicine;

  if (isLoading) return <div className="pt-20 page-container"><div className="card animate-pulse h-80" /></div>;
  if (!med) return <div className="pt-20 page-container text-slate-500">Medicine not found.</div>;

  return (
    <div className="pt-20 page-container">
      <Link to="/medicines" className="btn-ghost inline-flex items-center gap-2 mb-6 text-sm"><FiArrowLeft /> Back to Medicines</Link>
      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl h-72 flex items-center justify-center border border-slate-800">
          {med.images?.[0] ? <img src={med.images[0]} alt={med.name} className="max-h-full max-w-full object-contain p-8 rounded-3xl" /> : <MdLocalPharmacy className="text-8xl text-slate-600" />}
        </div>
        <div>
          {med.requiresPrescription && <span className="badge bg-amber-900/50 text-amber-300 border border-amber-700/50 mb-3">Prescription Required</span>}
          <h1 className="text-2xl font-extrabold text-slate-100 mb-1">{med.name}</h1>
          <p className="text-slate-400 mb-1">{med.genericName}</p>
          <p className="text-sm text-slate-500 mb-4">{med.brand} · {med.category} · {med.unit}</p>
          <div className="flex items-center gap-2 mb-6">
            <FiStar className="text-amber-400" />
            <span className="font-semibold text-slate-300">{med.rating?.toFixed(1)}</span>
            <span className="text-slate-500 text-sm">({med.reviews?.length} reviews)</span>
          </div>
          <div className="flex items-baseline gap-3 mb-6">
            <span className="text-3xl font-extrabold text-slate-100">₹{med.finalPrice?.toFixed(0)}</span>
            {med.mrp > med.finalPrice && <span className="text-lg text-slate-600 line-through">₹{med.mrp}</span>}
            {med.discount > 0 && <span className="badge bg-rose-900/50 text-rose-300 border border-rose-700/50">{med.discount}% off</span>}
          </div>
          <button onClick={() => { addItem(med); toast.success(`${med.name} added to cart`); }}
            className="btn-primary flex items-center gap-2 mb-6">
            <FiShoppingCart /> Add to Cart
          </button>
          {med.uses?.length > 0 && (
            <div className="mb-4">
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Uses</p>
              <div className="flex flex-wrap gap-2">{med.uses.map(u => <span key={u} className="flex items-center gap-1 text-sm text-teal-300 bg-teal-900/30 border border-teal-800/40 px-2.5 py-1 rounded-xl"><FiCheckCircle className="text-xs" />{u}</span>)}</div>
            </div>
          )}
          {med.description && <p className="text-sm text-slate-400 mt-4">{med.description}</p>}
        </div>
      </div>
    </div>
  );
}
