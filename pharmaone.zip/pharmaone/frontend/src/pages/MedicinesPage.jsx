import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { FiSearch, FiShoppingCart, FiStar, FiFilter } from 'react-icons/fi';
import { MdLocalPharmacy } from 'react-icons/md';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { useCartStore } from '../context/cartStore';

const CATEGORIES = ['All', 'OTC', 'Prescription', 'Vitamins', 'Ayurvedic', 'Surgical', 'Cosmetics'];

export default function MedicinesPage() {
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [category, setCategory] = useState('');
  const [sort, setSort] = useState('newest');
  const [page, setPage] = useState(1);
  const addItem = useCartStore((s) => s.addItem);

  const { data, isLoading } = useQuery({
    queryKey: ['medicines', search, category, sort, page],
    queryFn: () => api.get('/medicines', { params: { search, category: category || undefined, sort, page, limit: 20 } }).then((r) => r.data),
  });

  const handleSearch = (e) => { e.preventDefault(); setSearch(searchInput); setPage(1); };

  const handleAddToCart = (medicine, e) => {
    e.preventDefault();
    addItem(medicine);
    toast.success(`${medicine.name} added to cart`);
  };

  return (
    <div className="pt-20 page-container">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-9 h-9 bg-gradient-to-br from-teal-500 to-emerald-500 rounded-xl flex items-center justify-center">
            <MdLocalPharmacy className="text-white text-lg" />
          </div>
          <h1 className="section-title">Medicine Store</h1>
        </div>
        <p className="text-slate-400">Order 10,000+ medicines with doorstep delivery. Free delivery on orders above ₹500.</p>
      </div>

      {/* Search bar */}
      <form onSubmit={handleSearch} className="flex gap-3 mb-6">
        <div className="relative flex-1">
          <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
          <input value={searchInput} onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search medicines, generic names, brands…"
            className="input pl-11 h-12 text-base" />
        </div>
        <button type="submit" className="btn-primary h-12 px-6">Search</button>
      </form>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-8">
        <div className="flex items-center gap-2 text-slate-500 text-sm"><FiFilter /> Filter:</div>
        {CATEGORIES.map((cat) => (
          <button key={cat} onClick={() => { setCategory(cat === 'All' ? '' : cat); setPage(1); }}
            className={`chip ${(category === cat || (cat === 'All' && !category)) ? 'chip-active' : ''}`}>
            {cat}
          </button>
        ))}
        <div className="ml-auto">
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="input py-2 text-sm w-40">
            <option value="newest">Newest</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="popular">Most Popular</option>
          </select>
        </div>
      </div>

      {/* Results count */}
      {data && <p className="text-sm text-slate-500 mb-5">{data.total} medicines found</p>}

      {/* Grid */}
      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className="card animate-pulse h-64">
              <div className="bg-slate-800 rounded-xl h-32 mb-3" />
              <div className="bg-slate-800 rounded h-4 mb-2 w-3/4" />
              <div className="bg-slate-800 rounded h-3 w-1/2" />
            </div>
          ))}
        </div>
      ) : (
        <motion.div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {data?.medicines?.map((med, i) => (
            <motion.div key={med._id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>
              <Link to={`/medicines/${med._id}`} className="card flex flex-col h-full group hover:border-slate-700 hover:-translate-y-0.5 transition-all duration-200">
                {/* Image */}
                <div className="bg-gradient-to-br from-slate-800 to-slate-800/50 rounded-xl h-28 flex items-center justify-center mb-3 overflow-hidden relative">
                  {med.images?.[0] ? (
                    <img src={med.images[0]} alt={med.name} className="w-full h-full object-cover rounded-xl" />
                  ) : (
                    <MdLocalPharmacy className="text-4xl text-slate-600" />
                  )}
                  {med.discount > 0 && (
                    <span className="absolute top-2 right-2 badge bg-rose-900/80 text-rose-300 border border-rose-700/50">{med.discount}% off</span>
                  )}
                  {med.requiresPrescription && (
                    <span className="absolute top-2 left-2 badge bg-amber-900/80 text-amber-300 border border-amber-700/50 text-[9px]">Rx</span>
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 flex flex-col">
                  <p className="text-sm font-semibold text-slate-200 group-hover:text-teal-400 transition-colors line-clamp-2 mb-1">{med.name}</p>
                  <p className="text-xs text-slate-500 mb-1">{med.brand}</p>
                  <div className="flex items-center gap-1 mb-auto">
                    <FiStar className="text-amber-400 text-xs" />
                    <span className="text-xs text-slate-400">{med.rating?.toFixed(1)}</span>
                  </div>
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-800">
                    <div>
                      <span className="text-base font-bold text-slate-100">₹{med.finalPrice?.toFixed(0)}</span>
                      {med.mrp > med.finalPrice && (
                        <span className="text-xs text-slate-600 line-through ml-1.5">₹{med.mrp}</span>
                      )}
                    </div>
                    <button onClick={(e) => handleAddToCart(med, e)}
                      className="w-8 h-8 bg-teal-600 hover:bg-teal-500 text-white rounded-xl flex items-center justify-center transition-all active:scale-90 text-sm">
                      <FiShoppingCart />
                    </button>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      )}

      {/* Pagination */}
      {data?.pages > 1 && (
        <div className="flex justify-center gap-2 mt-10">
          {Array.from({ length: data.pages }).map((_, i) => (
            <button key={i} onClick={() => setPage(i + 1)}
              className={`w-10 h-10 rounded-xl text-sm font-medium transition-all ${page === i + 1 ? 'bg-teal-600 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
