import { Link } from 'react-router-dom';
import { FiArrowLeft } from 'react-icons/fi';

export default function NotFoundPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center px-4">
      <p className="text-8xl font-extrabold gradient-text mb-4">404</p>
      <h1 className="text-2xl font-bold text-slate-200 mb-2">Page Not Found</h1>
      <p className="text-slate-400 mb-8">The page you're looking for doesn't exist or has been moved.</p>
      <Link to="/" className="btn-primary flex items-center gap-2"><FiArrowLeft /> Back to Home</Link>
    </div>
  );
}
