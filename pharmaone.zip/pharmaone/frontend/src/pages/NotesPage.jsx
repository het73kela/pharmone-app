import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { FiSearch, FiBook, FiDownload, FiHeart, FiEye, FiUpload } from 'react-icons/fi';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { useAuthStore } from '../context/authStore';

const SUBJECTS = ['All', 'Pharmacology', 'Pharmaceutics', 'Pharmacognosy', 'Pharmaceutical Chemistry', 'Clinical Pharmacy', 'Hospital Pharmacy', 'Toxicology', 'Biochemistry'];
const YEARS = ['All', '1st Year', '2nd Year', '3rd Year', '4th Year', 'M.Pharm', 'Ph.D'];
const TYPES = ['All', 'Notes', 'Textbook', 'Question Paper', 'Handwritten', 'Slides'];

export default function NotesPage() {
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [subject, setSubject] = useState('');
  const [year, setYear] = useState('');
  const [type, setType] = useState('');
  const [page, setPage] = useState(1);
  const [showUpload, setShowUpload] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadForm, setUploadForm] = useState({ title: '', subject: '', year: '', type: 'Notes' });
  const [uploadFile, setUploadFile] = useState(null);
  const { token } = useAuthStore();

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['notes', search, subject, year, type, page],
    queryFn: () => api.get('/notes', { params: { search: search || undefined, subject: subject || undefined, year: year || undefined, type: type || undefined, page } }).then((r) => r.data),
  });

  const handleSearch = (e) => { e.preventDefault(); setSearch(searchInput); setPage(1); };

  const handleDownload = async (note) => {
    if (!token) return toast.error('Please login to download');
    try {
      const { data: res } = await api.get(`/notes/${note._id}/download`);
      window.open(res.fileUrl, '_blank');
      toast.success('Opening note…');
    } catch { toast.error('Download failed'); }
  };

  const handleLike = async (noteId) => {
    if (!token) return toast.error('Please login to like notes');
    await api.post(`/notes/${noteId}/like`);
    refetch();
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!uploadFile) return toast.error('Please select a PDF file');
    const formData = new FormData();
    Object.entries(uploadForm).forEach(([k, v]) => formData.append(k, v));
    formData.append('file', uploadFile);
    setUploading(true);
    try {
      await api.post('/notes', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success('Note uploaded! Pending admin approval.');
      setShowUpload(false);
      setUploadFile(null);
      setUploadForm({ title: '', subject: '', year: '', type: 'Notes' });
    } catch (err) { toast.error(err.response?.data?.message || 'Upload failed'); }
    finally { setUploading(false); }
  };

  return (
    <div className="pt-20 page-container">
      <div className="flex items-start justify-between mb-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <FiBook className="text-white text-lg" />
            </div>
            <h1 className="section-title">Pharmacy eNotes</h1>
          </div>
          <p className="text-slate-400">Free pharmacy notes, PDFs, and study materials for all years and subjects.</p>
        </div>
        {token && (
          <button onClick={() => setShowUpload(!showUpload)} className="btn-secondary flex items-center gap-2 flex-shrink-0">
            <FiUpload /> Share Notes
          </button>
        )}
      </div>

      {/* Upload form */}
      {showUpload && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="card mb-8 border-blue-800/30">
          <h3 className="font-bold text-slate-200 mb-5">Upload Study Material</h3>
          <form onSubmit={handleUpload} className="grid sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="label">Title</label>
              <input value={uploadForm.title} onChange={(e) => setUploadForm({ ...uploadForm, title: e.target.value })}
                className="input" placeholder="e.g. Pharmacokinetics Complete Notes - Unit 3" required />
            </div>
            <div>
              <label className="label">Subject</label>
              <select value={uploadForm.subject} onChange={(e) => setUploadForm({ ...uploadForm, subject: e.target.value })} className="input" required>
                <option value="">Select subject</option>
                {SUBJECTS.slice(1).map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Year</label>
              <select value={uploadForm.year} onChange={(e) => setUploadForm({ ...uploadForm, year: e.target.value })} className="input">
                <option value="">Select year</option>
                {YEARS.slice(1).map((y) => <option key={y} value={y}>{y}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Type</label>
              <select value={uploadForm.type} onChange={(e) => setUploadForm({ ...uploadForm, type: e.target.value })} className="input">
                {TYPES.slice(1).map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="label">PDF File</label>
              <input type="file" accept=".pdf" onChange={(e) => setUploadFile(e.target.files[0])} className="input py-2.5 text-sm" required />
            </div>
            <div className="sm:col-span-2 flex gap-3">
              <button type="submit" disabled={uploading} className="btn-primary flex items-center gap-2">
                {uploading ? <><div className="spinner" /> Uploading…</> : <><FiUpload /> Upload</>}
              </button>
              <button type="button" onClick={() => setShowUpload(false)} className="btn-secondary">Cancel</button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Search */}
      <form onSubmit={handleSearch} className="flex gap-3 mb-5">
        <div className="relative flex-1">
          <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
          <input value={searchInput} onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search notes by title, subject, or topic…" className="input pl-11 h-12" />
        </div>
        <button type="submit" className="btn-primary h-12 px-6">Search</button>
      </form>

      {/* Filters */}
      <div className="space-y-3 mb-8">
        <div className="flex flex-wrap gap-2">
          <span className="text-xs text-slate-500 pt-1.5">Subject:</span>
          {SUBJECTS.map((s) => (
            <button key={s} onClick={() => { setSubject(s === 'All' ? '' : s); setPage(1); }}
              className={`chip text-xs ${(subject === s || (s === 'All' && !subject)) ? 'chip-active' : ''}`}>{s}</button>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          <span className="text-xs text-slate-500 pt-1.5">Year:</span>
          {YEARS.map((y) => (
            <button key={y} onClick={() => { setYear(y === 'All' ? '' : y); setPage(1); }}
              className={`chip text-xs ${(year === y || (y === 'All' && !year)) ? 'chip-active' : ''}`}>{y}</button>
          ))}
        </div>
      </div>

      {/* Grid */}
      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => <div key={i} className="card animate-pulse h-48"><div className="bg-slate-800 h-full rounded-xl" /></div>)}
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {data?.notes?.map((note, i) => (
            <motion.div key={note._id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
              className="card group hover:border-slate-700 hover:-translate-y-0.5 transition-all duration-200 flex flex-col">
              {/* Cover / icon */}
              <div className="bg-gradient-to-br from-blue-900/40 to-cyan-900/30 rounded-xl h-24 flex items-center justify-center mb-4 relative overflow-hidden">
                <FiBook className="text-4xl text-blue-400/40" />
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-xs font-bold text-blue-300/60 uppercase tracking-widest">{note.type}</span>
                </div>
              </div>

              <h3 className="text-sm font-semibold text-slate-200 group-hover:text-blue-400 transition-colors mb-1 line-clamp-2">{note.title}</h3>
              <div className="flex flex-wrap gap-1.5 mb-3">
                <span className="badge bg-blue-900/40 text-blue-300 border border-blue-700/40 text-[10px]">{note.subject?.split(' ')[0]}</span>
                {note.year && <span className="badge bg-slate-800 text-slate-400 border border-slate-700 text-[10px]">{note.year}</span>}
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500 mt-auto pt-3 border-t border-slate-800">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1"><FiDownload /> {note.downloads}</span>
                  <span className="flex items-center gap-1"><FiEye /> {note.views}</span>
                  <button onClick={() => handleLike(note._id)} className="flex items-center gap-1 hover:text-rose-400 transition-colors">
                    <FiHeart /> {note.likes?.length || 0}
                  </button>
                </div>
                <button onClick={() => handleDownload(note)} className="text-teal-400 hover:text-teal-300 font-medium transition-colors">
                  View →
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {!isLoading && data?.notes?.length === 0 && (
        <div className="text-center py-16 text-slate-600">
          <FiBook className="text-5xl mx-auto mb-3 opacity-30" />
          <p className="font-medium">No notes found</p>
        </div>
      )}
    </div>
  );
}
