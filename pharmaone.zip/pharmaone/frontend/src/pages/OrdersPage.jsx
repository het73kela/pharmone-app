// OrdersPage.jsx
import { useQuery } from '@tanstack/react-query';
import { FiPackage, FiClock } from 'react-icons/fi';
import api from '../utils/api';

const statusColor = { Placed:'amber', Confirmed:'blue', Packed:'purple', Shipped:'cyan', OutForDelivery:'orange', Delivered:'emerald', Cancelled:'rose' };

export default function OrdersPage() {
  const { data, isLoading } = useQuery({ queryKey: ['my-orders'], queryFn: () => api.get('/orders/my').then(r => r.data) });

  return (
    <div className="pt-20 page-container">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-9 h-9 bg-gradient-to-br from-teal-500 to-emerald-500 rounded-xl flex items-center justify-center">
          <FiPackage className="text-white" />
        </div>
        <h1 className="section-title">My Orders</h1>
      </div>

      {isLoading && <div className="space-y-4">{Array.from({length:3}).map((_,i) => <div key={i} className="card animate-pulse h-28" />)}</div>}

      {data?.orders?.length === 0 && (
        <div className="text-center py-16 text-slate-600">
          <FiPackage className="text-5xl mx-auto mb-3 opacity-30" />
          <p className="font-medium">No orders yet</p>
        </div>
      )}

      <div className="space-y-4">
        {data?.orders?.map((order) => {
          const c = statusColor[order.orderStatus] || 'slate';
          return (
            <div key={order._id} className="card">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="font-bold text-slate-200">Order #{order._id.slice(-8).toUpperCase()}</p>
                  <p className="text-sm text-slate-500 flex items-center gap-1 mt-0.5">
                    <FiClock className="text-xs" /> {new Date(order.createdAt).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' })}
                  </p>
                </div>
                <span className={`badge bg-${c}-900/50 text-${c}-300 border border-${c}-700/50`}>{order.orderStatus}</span>
              </div>

              <div className="space-y-2 mb-4">
                {order.items?.slice(0, 3).map((item) => (
                  <div key={item._id} className="flex items-center gap-3 text-sm">
                    <div className="w-8 h-8 bg-slate-800 rounded-lg overflow-hidden flex-shrink-0">
                      {item.medicine?.images?.[0] && <img src={item.medicine.images[0]} alt="" className="w-full h-full object-cover" />}
                    </div>
                    <span className="text-slate-300 flex-1 truncate">{item.name}</span>
                    <span className="text-slate-500">×{item.quantity}</span>
                    <span className="text-slate-300 font-medium">₹{(item.price * item.quantity).toFixed(0)}</span>
                  </div>
                ))}
                {order.items?.length > 3 && <p className="text-xs text-slate-500">+{order.items.length - 3} more items</p>}
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-800 text-sm">
                <p className="text-slate-400">Total: <span className="text-slate-100 font-bold">₹{order.total}</span></p>
                <p className="text-slate-500">{order.paymentMethod} · {order.paymentStatus}</p>
              </div>

              {order.trackingHistory?.length > 0 && (
                <div className="mt-4 pt-4 border-t border-slate-800">
                  <p className="text-xs text-slate-500 font-medium mb-2">Latest Update</p>
                  <p className="text-sm text-slate-300">{order.trackingHistory.at(-1).message}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
