// ProfilePage.jsx
import { useState } from 'react';
import { FiUser, FiSave } from 'react-icons/fi';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { useAuthStore } from '../context/authStore';

export default function ProfilePage() {
  const { user, updateUser } = useAuthStore();
  const [form, setForm] = useState({ name: user?.name || '', phone: user?.phone || '', specialization: user?.specialization || '', qualification: user?.qualification || '', experience: user?.experience || '', consultationFee: user?.consultationFee || '' });
  const [saving, setSaving] = useState(false);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const { data } = await api.put('/auth/profile', form);
      updateUser(data.user);
      toast.success('Profile updated!');
    } catch { toast.error('Update failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="pt-20 page-container max-w-2xl">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-9 h-9 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-xl flex items-center justify-center">
          <FiUser className="text-white" />
        </div>
        <h1 className="section-title">My Profile</h1>
      </div>

      <div className="card">
        <div className="flex items-center gap-4 mb-8 pb-6 border-b border-slate-800">
          <div className="w-20 h-20 bg-gradient-to-br from-teal-600 to-cyan-600 rounded-2xl flex items-center justify-center text-3xl font-bold text-white">
            {user?.name?.charAt(0)}
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-100">{user?.name}</h2>
            <p className="text-slate-400">{user?.email}</p>
            <span className="badge bg-teal-900/50 text-teal-300 border border-teal-800 capitalize mt-1">{user?.role}</span>
          </div>
        </div>

        <form onSubmit={handleSave} className="grid sm:grid-cols-2 gap-5">
          <div><label className="label">Full Name</label><input value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="input" /></div>
          <div><label className="label">Phone</label><input value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} className="input" placeholder="+91..." /></div>
          {user?.role === 'doctor' && (
            <>
              <div><label className="label">Specialization</label><input value={form.specialization} onChange={e => setForm({...form, specialization: e.target.value})} className="input" /></div>
              <div><label className="label">Qualification</label><input value={form.qualification} onChange={e => setForm({...form, qualification: e.target.value})} className="input" /></div>
              <div><label className="label">Experience (years)</label><input type="number" value={form.experience} onChange={e => setForm({...form, experience: e.target.value})} className="input" /></div>
              <div><label className="label">Consultation Fee (₹)</label><input type="number" value={form.consultationFee} onChange={e => setForm({...form, consultationFee: e.target.value})} className="input" /></div>
            </>
          )}
          <div className="sm:col-span-2">
            <button type="submit" disabled={saving} className="btn-primary flex items-center gap-2">
              {saving ? <><div className="spinner" /> Saving…</> : <><FiSave /> Save Changes</>}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
