import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiSearch, FiUpload, FiFile, FiZap, FiBookOpen, FiUsers, FiCheckCircle, FiAlertCircle } from 'react-icons/fi';
import { useQuery } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { useAuthStore } from '../context/authStore';

export default function ResearchPage() {
  const [tab, setTab] = useState('search'); // 'search' | 'upload'
  const [query, setQuery] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [page, setPage] = useState(1);
  const [selectedPaper, setSelectedPaper] = useState(null);
  const [aiSummary, setAiSummary] = useState(null);
  const [summarizing, setSummarizing] = useState(null);
  const [uploadFile, setUploadFile] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [uploadResult, setUploadResult] = useState(null);
  const fileRef = useRef();
  const { token } = useAuthStore();

  const { data: searchData, isLoading: searching } = useQuery({
    queryKey: ['research', query, page],
    queryFn: () => api.get('/research/search', { params: { q: query, page } }).then((r) => r.data),
    enabled: !!query,
  });

  const handleSearch = (e) => { e.preventDefault(); setQuery(searchInput); setPage(1); };

  const handleSummarize = async (paper) => {
    setSummarizing(paper.pubmedId);
    try {
      const { data } = await api.post('/research/summarize-pubmed', { pubmedId: paper.pubmedId, title: paper.title, abstract: paper.abstract });
      setAiSummary({ ...data.analysis, paper });
      setSelectedPaper(paper);
    } catch { toast.error('AI summarization failed'); }
    finally { setSummarizing(null); }
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!uploadFile) return toast.error('Please select a PDF file');
    if (!token) return toast.error('Please login to analyze papers');

    const formData = new FormData();
    formData.append('pdf', uploadFile);
    setAnalyzing(true);
    try {
      const { data } = await api.post('/research/analyze', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      setUploadResult(data.paper);
      toast.success('Paper analyzed successfully!');
    } catch (err) { toast.error(err.response?.data?.message || 'Analysis failed'); }
    finally { setAnalyzing(false); }
  };

  return (
    <div className="pt-20 page-container">
      {/* Header */}
      <div className="mb-8 flex items-start gap-4">
        <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-500 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-amber-500/20">
          <FiSearch className="text-white text-xl" />
        </div>
        <div>
          <h1 className="section-title mb-1">AI Research Analyzer</h1>
          <p className="text-slate-400">Search PubMed or upload any research paper. Our AI powered by GPT-4o summarizes, finds key findings, and explains the methodology.</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-8 p-1 bg-slate-900 rounded-2xl w-fit border border-slate-800">
        {[{ id: 'search', label: '🔍 Search PubMed' }, { id: 'upload', label: '📄 Upload PDF' }].map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`px-5 py-2.5 rounded-xl text-sm font-semibold transition-all ${tab === t.id ? 'bg-teal-600 text-white shadow-lg' : 'text-slate-400 hover:text-slate-200'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'search' && (
        <div>
          <form onSubmit={handleSearch} className="flex gap-3 mb-8">
            <div className="relative flex-1">
              <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
              <input value={searchInput} onChange={(e) => setSearchInput(e.target.value)}
                placeholder="Search PubMed: e.g. 'drug resistance antibiotics', 'pharmacokinetics diabetes'…"
                className="input pl-11 h-12 text-base" />
            </div>
            <button type="submit" className="btn-primary h-12 px-6">Search</button>
          </form>

          {!query && (
            <div className="text-center py-16 text-slate-600">
              <FiSearch className="text-5xl mx-auto mb-4 opacity-30" />
              <p className="text-lg font-medium">Search millions of pharmacy & medical research papers</p>
              <p className="text-sm mt-1">Powered by PubMed · NCBI database</p>
            </div>
          )}

          {searching && (
            <div className="space-y-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="card animate-pulse">
                  <div className="bg-slate-800 h-5 rounded w-3/4 mb-2" />
                  <div className="bg-slate-800 h-3 rounded w-1/2 mb-4" />
                  <div className="bg-slate-800 h-3 rounded w-full mb-2" />
                  <div className="bg-slate-800 h-3 rounded w-5/6" />
                </div>
              ))}
            </div>
          )}

          {searchData?.papers?.map((paper) => (
            <motion.div key={paper.pubmedId} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
              className="card mb-4 hover:border-slate-700 transition-all">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <h3 className="text-base font-semibold text-slate-200 mb-2 leading-snug"
                    dangerouslySetInnerHTML={{ __html: paper.title }} />
                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mb-3">
                    <span className="flex items-center gap-1"><FiUsers /> {paper.authors?.slice(0, 3).join(', ')}{paper.authors?.length > 3 ? ' et al.' : ''}</span>
                    <span className="flex items-center gap-1"><FiBookOpen /> {paper.journal}</span>
                    <span>{paper.publishedDate}</span>
                    {paper.doi && <a href={`https://doi.org/${paper.doi}`} target="_blank" rel="noreferrer" className="text-teal-500 hover:text-teal-400">DOI ↗</a>}
                  </div>
                  {paper.abstract && <p className="text-sm text-slate-400 line-clamp-3">{paper.abstract}</p>}
                </div>
                <button onClick={() => handleSummarize(paper)} disabled={summarizing === paper.pubmedId}
                  className="flex-shrink-0 flex items-center gap-1.5 bg-amber-900/40 hover:bg-amber-900/60 border border-amber-700/50 text-amber-300 text-xs font-semibold px-3 py-2 rounded-xl transition-all disabled:opacity-50">
                  {summarizing === paper.pubmedId ? <div className="spinner w-3.5 h-3.5" /> : <FiZap />}
                  AI Analyze
                </button>
              </div>

              {/* AI Summary panel */}
              <AnimatePresence>
                {selectedPaper?.pubmedId === paper.pubmedId && aiSummary && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                    className="mt-5 pt-5 border-t border-slate-800">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-6 h-6 bg-gradient-to-br from-amber-500 to-orange-500 rounded-lg flex items-center justify-center">
                        <FiZap className="text-white text-xs" />
                      </div>
                      <span className="text-sm font-bold text-amber-300">AI Analysis</span>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="bg-slate-800/50 rounded-xl p-4">
                        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Summary</p>
                        <p className="text-sm text-slate-300">{aiSummary.summary}</p>
                      </div>
                      <div className="bg-slate-800/50 rounded-xl p-4">
                        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Key Findings</p>
                        <ul className="space-y-1.5">
                          {aiSummary.keyFindings?.map((f, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-slate-300">
                              <FiCheckCircle className="text-emerald-400 mt-0.5 flex-shrink-0 text-xs" /> {f}
                            </li>
                          ))}
                        </ul>
                      </div>
                      {aiSummary.clinicalRelevance && (
                        <div className="md:col-span-2 bg-teal-900/20 border border-teal-800/40 rounded-xl p-4">
                          <p className="text-xs font-semibold text-teal-400 uppercase tracking-wider mb-2">Clinical Relevance</p>
                          <p className="text-sm text-slate-300">{aiSummary.clinicalRelevance}</p>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}

          {searchData?.pages > 1 && (
            <div className="flex justify-center gap-2 mt-6">
              {Array.from({ length: Math.min(searchData.pages, 5) }).map((_, i) => (
                <button key={i} onClick={() => setPage(i + 1)}
                  className={`w-10 h-10 rounded-xl text-sm font-medium transition-all ${page === i + 1 ? 'bg-teal-600 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
                  {i + 1}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'upload' && (
        <div className="max-w-2xl">
          <form onSubmit={handleUpload}>
            <div
              onClick={() => fileRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all ${uploadFile ? 'border-teal-500 bg-teal-900/10' : 'border-slate-700 hover:border-slate-600'}`}>
              <input ref={fileRef} type="file" accept=".pdf" className="hidden"
                onChange={(e) => setUploadFile(e.target.files[0])} />
              {uploadFile ? (
                <>
                  <FiFile className="text-5xl text-teal-400 mx-auto mb-3" />
                  <p className="font-semibold text-teal-300">{uploadFile.name}</p>
                  <p className="text-sm text-slate-500 mt-1">{(uploadFile.size / 1024 / 1024).toFixed(2)} MB</p>
                  <button type="button" onClick={(e) => { e.stopPropagation(); setUploadFile(null); }}
                    className="mt-3 text-xs text-slate-500 hover:text-rose-400 transition-colors">Remove</button>
                </>
              ) : (
                <>
                  <FiUpload className="text-5xl text-slate-600 mx-auto mb-3" />
                  <p className="text-lg font-semibold text-slate-400">Drop your research paper here</p>
                  <p className="text-sm text-slate-600 mt-1">or click to browse · PDF up to 20MB</p>
                </>
              )}
            </div>

            <button type="submit" disabled={!uploadFile || analyzing} className="btn-primary w-full mt-4 py-3 flex items-center justify-center gap-2">
              {analyzing ? <><div className="spinner" /> Analyzing with GPT-4o…</> : <><FiZap /> Analyze Paper</>}
            </button>
          </form>

          {uploadResult && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-8 card border-amber-800/30">
              <div className="flex items-center gap-2 mb-5">
                <FiZap className="text-amber-400 text-xl" />
                <h2 className="text-lg font-bold text-slate-100">AI Analysis Complete</h2>
              </div>
              {uploadResult.title && <h3 className="text-base font-semibold text-slate-200 mb-4">{uploadResult.title}</h3>}
              {uploadResult.aiSummary && (
                <div className="bg-slate-800/50 rounded-xl p-4 mb-4">
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Summary</p>
                  <p className="text-sm text-slate-300">{uploadResult.aiSummary}</p>
                </div>
              )}
              {uploadResult.aiKeyFindings?.length > 0 && (
                <div className="bg-slate-800/50 rounded-xl p-4 mb-4">
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Key Findings</p>
                  <ul className="space-y-2">
                    {uploadResult.aiKeyFindings.map((f, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-slate-300">
                        <FiCheckCircle className="text-emerald-400 mt-0.5 flex-shrink-0 text-xs" /> {f}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              <div className="grid md:grid-cols-2 gap-4">
                {uploadResult.aiMethodology && (
                  <div className="bg-slate-800/50 rounded-xl p-4">
                    <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Methodology</p>
                    <p className="text-sm text-slate-300">{uploadResult.aiMethodology}</p>
                  </div>
                )}
                {uploadResult.aiConclusion && (
                  <div className="bg-slate-800/50 rounded-xl p-4">
                    <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Conclusion</p>
                    <p className="text-sm text-slate-300">{uploadResult.aiConclusion}</p>
                  </div>
                )}
              </div>
              {uploadResult.aiLimitations?.length > 0 && (
                <div className="bg-amber-900/20 border border-amber-800/30 rounded-xl p-4 mt-4">
                  <p className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">Limitations</p>
                  <ul className="space-y-1">
                    {uploadResult.aiLimitations.map((l, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-slate-300">
                        <FiAlertCircle className="text-amber-400 mt-0.5 flex-shrink-0 text-xs" /> {l}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </motion.div>
          )}
        </div>
      )}
    </div>
  );
}
